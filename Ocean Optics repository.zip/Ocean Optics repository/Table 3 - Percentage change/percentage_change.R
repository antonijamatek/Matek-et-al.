library(dplyr)
library(openxlsx)

# =====================================================
# Helper function
# =====================================================

calc_change <- function(itw, ref) {
  (itw - ref) / ref * 100
}

# =====================================================
# M1 vs P4 (June 2022)
# =====================================================

M1_vs_P4 <- full_join(
  df_2022 %>%
    filter(Station == "M1") %>%
    select(z, PT_M1 = `PT _z`, PBT_M1 = PBT_Z),
  
  df_2022 %>%
    filter(Station == "P4") %>%
    select(z, PT_P4 = `PT _z`, PBT_P4 = PBT_Z),
  
  by = "z"
) %>%
  mutate(
    PT_change = calc_change(PT_M1, PT_P4),
    PBT_change = calc_change(PBT_M1, PBT_P4)
  )

# =====================================================
# S0 vs P4 (June 2022)
# =====================================================

S0_vs_P4 <- full_join(
  df_2022 %>%
    filter(Station == "S0") %>%
    select(z, PT_S0 = `PT _z`, PBT_S0 = PBT_Z),
  
  df_2022 %>%
    filter(Station == "P4") %>%
    select(z, PT_P4 = `PT _z`, PBT_P4 = PBT_Z),
  
  by = "z"
) %>%
  mutate(
    PT_change = calc_change(PT_S0, PT_P4),
    PBT_change = calc_change(PBT_S0, PBT_P4)
  )

# =====================================================
# S0-04 vs S0-16 (July 2023)
# =====================================================

S004_vs_S016 <- full_join(
  df_2023 %>%
    filter(Station == "S0-04") %>%
    select(z, PT_04 = `PT _z`, PBT_04 = PBT_Z),
  
  df_2023 %>%
    filter(Station == "S0-16") %>%
    select(z, PT_16 = `PT _z`, PBT_16 = PBT_Z),
  
  by = "z"
) %>%
  mutate(
    PT_change = calc_change(PT_04, PT_16),
    PBT_change = calc_change(PBT_04, PBT_16)
  )

# =====================================================
# S0-08 vs S0-16 (July 2023)
# =====================================================

S008_vs_S016 <- full_join(
  df_2023 %>%
    filter(Station == "S0-08") %>%
    select(z, PT_08 = `PT _z`, PBT_08 = PBT_Z),
  
  df_2023 %>%
    filter(Station == "S0-16") %>%
    select(z, PT_16 = `PT _z`, PBT_16 = PBT_Z),
  
  by = "z"
) %>%
  mutate(
    PT_change = calc_change(PT_08, PT_16),
    PBT_change = calc_change(PBT_08, PBT_16)
  )

# =====================================================
# Integrated production (Pz,T)
# =====================================================

PZT_integrated <- tibble(
  Comparison = c(
    "M1 vs P4",
    "S0 vs P4",
    "S0-04 vs S0-16",
    "S0-08 vs S0-16"
  ),
  
  Reference = c(
    87.46,
    87.46,
    97.11,
    97.11
  ),
  
  ITW = c(
    173.06,
    190.04,
    184.03,
    190.75
  )
) %>%
  mutate(
    Percent_change = calc_change(ITW, Reference)
  )

# =====================================================
# Round values
# =====================================================

M1_vs_P4    <- M1_vs_P4    %>% mutate(across(where(is.numeric), round, 1))
S0_vs_P4    <- S0_vs_P4    %>% mutate(across(where(is.numeric), round, 1))
S004_vs_S016 <- S004_vs_S016 %>% mutate(across(where(is.numeric), round, 1))
S008_vs_S016 <- S008_vs_S016 %>% mutate(across(where(is.numeric), round, 1))
PZT_integrated <- PZT_integrated %>% mutate(across(where(is.numeric), round, 1))

# =====================================================
# Export to Excel
# =====================================================

wb <- createWorkbook()

addWorksheet(wb, "M1_vs_P4")
writeData(wb, "M1_vs_P4", M1_vs_P4)

addWorksheet(wb, "S0_vs_P4")
writeData(wb, "S0_vs_P4", S0_vs_P4)

addWorksheet(wb, "S0-04_vs_S0-16")
writeData(wb, "S0-04_vs_S0-16", S004_vs_S016)

addWorksheet(wb, "S0-08_vs_S0-16")
writeData(wb, "S0-08_vs_S0-16", S008_vs_S016)

addWorksheet(wb, "Integrated_PZT")
writeData(wb, "Integrated_PZT", PZT_integrated)

saveWorkbook(
  wb,
  "ITW_Percentage_Differences.xlsx",
  overwrite = TRUE
)
