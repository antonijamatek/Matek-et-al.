library(dplyr)
library(openxlsx)
library(pracma)   # for trapz()

# =====================================================
# Helper functions
# =====================================================

calc_change <- function(itw, ref) {
  (itw - ref) / ref * 100
}

integrate_profile <- function(z, value) {
  ok <- !is.na(z) & !is.na(value)
  z <- z[ok]
  value <- value[ok]
  
  if (length(z) == 0) return(NA_real_)
  
  # If only one point exists in the layer,
  # use that single value directly
  if (length(z) == 1) return(value)
  
  ord <- order(z)
  trapz(z[ord], value[ord])
}

# =====================================================
# Layer-integrated PT(z) and PBT(z)
# =====================================================

df_2022_layer_int <- df_2022 %>%
  group_by(Station, Layer) %>%
  summarise(
    PT_integrated_layer  = integrate_profile(z, `PT _z`),
    PBT_integrated_layer = integrate_profile(z, PBT_Z),
    .groups = "drop"
  )

df_2023_layer_int <- df_2023 %>%
  group_by(Station, Layer) %>%
  summarise(
    PT_integrated_layer  = integrate_profile(z, `PT _z`),
    PBT_integrated_layer = integrate_profile(z, PBT_Z),
    .groups = "drop"
  )

# =====================================================
# Whole-water-column integrated PT(z) and PBT(z)
# =====================================================

df_2022_total_int <- df_2022 %>%
  group_by(Station) %>%
  summarise(
    PT_integrated_total  = integrate_profile(z, `PT _z`),
    PBT_integrated_total = integrate_profile(z, PBT_Z),
    .groups = "drop"
  )

df_2023_total_int <- df_2023 %>%
  group_by(Station) %>%
  summarise(
    PT_integrated_total  = integrate_profile(z, `PT _z`),
    PBT_integrated_total = integrate_profile(z, PBT_Z),
    .groups = "drop"
  )

# =====================================================
# Function for layer comparisons
# =====================================================

compare_layers <- function(df, itw_station, ref_station) {
  
  full_join(
    df %>%
      filter(Station == itw_station) %>%
      select(
        Layer,
        PT_ITW = PT_integrated_layer,
        PBT_ITW = PBT_integrated_layer
      ),
    
    df %>%
      filter(Station == ref_station) %>%
      select(
        Layer,
        PT_REF = PT_integrated_layer,
        PBT_REF = PBT_integrated_layer
      ),
    
    by = "Layer"
  ) %>%
    mutate(
      Comparison = paste(itw_station, "vs", ref_station),
      PT_percent_change = calc_change(PT_ITW, PT_REF),
      PBT_percent_change = calc_change(PBT_ITW, PBT_REF)
    ) %>%
    select(
      Comparison, Layer,
      PT_REF, PT_ITW, PT_percent_change,
      PBT_REF, PBT_ITW, PBT_percent_change
    )
}

# =====================================================
# Function for whole-water-column comparisons
# =====================================================

compare_total <- function(df, itw_station, ref_station) {
  
  full_join(
    df %>%
      filter(Station == itw_station) %>%
      select(
        PT_ITW = PT_integrated_total,
        PBT_ITW = PBT_integrated_total
      ),
    
    df %>%
      filter(Station == ref_station) %>%
      select(
        PT_REF = PT_integrated_total,
        PBT_REF = PBT_integrated_total
      ),
    
    by = character()
  ) %>%
    mutate(
      Comparison = paste(itw_station, "vs", ref_station),
      Layer = "Integrated water column",
      PT_percent_change = calc_change(PT_ITW, PT_REF),
      PBT_percent_change = calc_change(PBT_ITW, PBT_REF)
    ) %>%
    select(
      Comparison, Layer,
      PT_REF, PT_ITW, PT_percent_change,
      PBT_REF, PBT_ITW, PBT_percent_change
    )
}

# =====================================================
# Layer-integrated comparisons
# =====================================================

layer_comparisons <- bind_rows(
  compare_layers(df_2022_layer_int, "M1", "P4"),
  compare_layers(df_2022_layer_int, "M1", "S0"),
  compare_layers(df_2023_layer_int, "S0-04", "S0-16"),
  compare_layers(df_2023_layer_int, "S0-08", "S0-16")
)

# =====================================================
# Whole-water-column comparisons
# =====================================================

total_comparisons <- bind_rows(
  compare_total(df_2022_total_int, "M1", "P4"),
  compare_total(df_2022_total_int, "M1", "S0"),
  compare_total(df_2023_total_int, "S0-04", "S0-16"),
  compare_total(df_2023_total_int, "S0-08", "S0-16")
)

# =====================================================
# Final table
# =====================================================

integrated_percentage_change <- bind_rows(
  total_comparisons,
  layer_comparisons
) %>%
  mutate(across(where(is.numeric), ~ round(.x, 1)))

# =====================================================
# Save Excel workbook
# =====================================================

wb <- createWorkbook()

addWorksheet(wb, "Integrated_percentage_change")
writeData(wb, "Integrated_percentage_change", integrated_percentage_change)

addWorksheet(wb, "Layer_integrated_2022")
writeData(wb, "Layer_integrated_2022", df_2022_layer_int)

addWorksheet(wb, "Layer_integrated_2023")
writeData(wb, "Layer_integrated_2023", df_2023_layer_int)

addWorksheet(wb, "Total_integrated_2022")
writeData(wb, "Total_integrated_2022", df_2022_total_int)

addWorksheet(wb, "Total_integrated_2023")
writeData(wb, "Total_integrated_2023", df_2023_total_int)

saveWorkbook(
  wb,
  "ITW_Percentage_Differences_integrated_PT_PBT.xlsx",
  overwrite = TRUE
)
