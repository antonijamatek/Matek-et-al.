library(dplyr)
library(openxlsx)

# =====================================================
# Helper function
# =====================================================

calc_change <- function(itw, ref) {
  (itw - ref) / ref * 100
}

# =====================================================
# Prepare layer-level means
# =====================================================

df_2022_layer <- df_2022 %>%
  group_by(Station, Layer) %>%
  summarise(
    PT_mean = mean(`PT _z`, na.rm = TRUE),
    PBT_mean = mean(PBT_Z, na.rm = TRUE),
    .groups = "drop"
  )

df_2023_layer <- df_2023 %>%
  group_by(Station, Layer) %>%
  summarise(
    PT_mean = mean(`PT _z`, na.rm = TRUE),
    PBT_mean = mean(PBT_Z, na.rm = TRUE),
    .groups = "drop"
  )

# =====================================================
# M1 vs P4 (June 2022)
# =====================================================

M1_vs_P4_layer <- full_join(
  df_2022_layer %>%
    filter(Station == "M1") %>%
    select(Layer, PT_M1 = PT_mean, PBT_M1 = PBT_mean),
  
  df_2022_layer %>%
    filter(Station == "P4") %>%
    select(Layer, PT_P4 = PT_mean, PBT_P4 = PBT_mean),
  
  by = "Layer"
) %>%
  mutate(
    PT_change = calc_change(PT_M1, PT_P4),
    PBT_change = calc_change(PBT_M1, PBT_P4)
  )

# =====================================================
# S0 vs P4 (June 2022)
# =====================================================

S0_vs_P4_layer <- full_join(
  df_2022_layer %>%
    filter(Station == "S0") %>%
    select(Layer, PT_S0 = PT_mean, PBT_S0 = PBT_mean),
  
  df_2022_layer %>%
    filter(Station == "P4") %>%
    select(Layer, PT_P4 = PT_mean, PBT_P4 = PBT_mean),
  
  by = "Layer"
) %>%
  mutate(
    PT_change = calc_change(PT_S0, PT_P4),
    PBT_change = calc_change(PBT_S0, PBT_P4)
  )

# =====================================================
# S0-04 vs S0-16 (July 2023)
# =====================================================

S004_vs_S016_layer <- full_join(
  df_2023_layer %>%
    filter(Station == "S0-04") %>%
    select(Layer, PT_04 = PT_mean, PBT_04 = PBT_mean),
  
  df_2023_layer %>%
    filter(Station == "S0-16") %>%
    select(Layer, PT_16 = PT_mean, PBT_16 = PBT_mean),
  
  by = "Layer"
) %>%
  mutate(
    PT_change = calc_change(PT_04, PT_16),
    PBT_change = calc_change(PBT_04, PBT_16)
  )

# =====================================================
# S0-08 vs S0-16 (July 2023)
# =====================================================

S008_vs_S016_layer <- full_join(
  df_2023_layer %>%
    filter(Station == "S0-08") %>%
    select(Layer, PT_08 = PT_mean, PBT_08 = PBT_mean),
  
  df_2023_layer %>%
    filter(Station == "S0-16") %>%
    select(Layer, PT_16 = PT_mean, PBT_16 = PBT_mean),
  
  by = "Layer"
) %>%
  mutate(
    PT_change = calc_change(PT_08, PT_16),
    PBT_change = calc_change(PBT_08, PBT_16)
  )

# =====================================================
# Integrated production Pz,T
# =====================================================

PZT_integrated <- tibble(
  Comparison = c(
    "M1 vs P4",
    "S0 vs P4",
    "S0-04 vs S0-16",
    "S0-08 vs S0-16"
  ),
  Reference = c(
    87.46,
    87.46,
    97.11,
    97.11
  ),
  ITW = c(
    173.06,
    190.04,
    184.03,
    190.75
  )
) %>%
  mutate(
    Percent_change = calc_change(ITW, Reference)
  )

# =====================================================
# Round values
# =====================================================

M1_vs_P4_layer <- M1_vs_P4_layer %>%
  mutate(across(where(is.numeric), ~ round(.x, 1)))

S0_vs_P4_layer <- S0_vs_P4_layer %>%
  mutate(across(where(is.numeric), ~ round(.x, 1)))

S004_vs_S016_layer <- S004_vs_S016_layer %>%
  mutate(across(where(is.numeric), ~ round(.x, 1)))

S008_vs_S016_layer <- S008_vs_S016_layer %>%
  mutate(across(where(is.numeric), ~ round(.x, 1)))

PZT_integrated <- PZT_integrated %>%
  mutate(across(where(is.numeric), ~ round(.x, 1)))

# =====================================================
# Save Excel workbook
# =====================================================

wb <- createWorkbook()

addWorksheet(wb, "M1_vs_P4_layer")
writeData(wb, "M1_vs_P4_layer", M1_vs_P4_layer)

addWorksheet(wb, "S0_vs_P4_layer")
writeData(wb, "S0_vs_P4_layer", S0_vs_P4_layer)

addWorksheet(wb, "S0-04_vs_S0-16_layer")
writeData(wb, "S0-04_vs_S0-16_layer", S004_vs_S016_layer)

addWorksheet(wb, "S0-08_vs_S0-16_layer")
writeData(wb, "S0-08_vs_S0-16_layer", S008_vs_S016_layer)

addWorksheet(wb, "Integrated_PZT")
writeData(wb, "Integrated_PZT", PZT_integrated)

saveWorkbook(
  wb,
  "ITW_Percentage_Differences_by_Layer.xlsx",
  overwrite = TRUE
)