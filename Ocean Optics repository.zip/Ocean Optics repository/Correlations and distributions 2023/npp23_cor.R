library("vegan")
library("dplyr")
library("readr")
library("ggvegan")
library("ggrepel")
library("ggplot2")
library("tibble")

#**CORRELATE 2023 NPP AND ENVIRONMENT DATA TO COMPARE WITH THE LC PREDICTED SCORES**

# ---------------------------
# 0) Helper functions
# ---------------------------

lm_stats_row <- function(fit, response, model_name) {
  s <- summary(fit)
  fstat <- s$fstatistic
  
  p_model <- if (!is.null(fstat)) {
    pf(fstat[1], fstat[2], fstat[3], lower.tail = FALSE)
  } else {
    NA_real_
  }
  
  data.frame(
    Response = response,
    Model    = model_name,
    n        = nobs(fit),
    R2       = unname(s$r.squared),
    adjR2    = unname(s$adj.r.squared),
    F        = if (!is.null(fstat)) unname(fstat[1]) else NA_real_,
    df1      = if (!is.null(fstat)) unname(fstat[2]) else NA_real_,
    df2      = if (!is.null(fstat)) unname(fstat[3]) else NA_real_,
    p_value  = p_model,
    AIC      = AIC(fit),
    stringsAsFactors = FALSE
  )
}

# helper: wrap non-syntactic names in backticks (keeps normal names unchanged)
bt <- function(x) ifelse(make.names(x) != x, paste0("`", x, "`"), x)

# Fit your fixed model-set for a given response variable name
fit_model_set <- function(data, response_var) {
  
  preds_full  <- c("NO3","PO4","SiO4","Temperature (°C)","Chla","Oxygen (mgL-1)")
  preds_red1  <- c("Temperature (°C)","NO3","PO4","Chla")
  preds_red2  <- c("Temperature (°C)","NO3","Chla")
  preds_red3  <- c("Temperature (°C)","NO3")
  
  preds_oxy   <- c("Oxygen (mgL-1)")
  preds_oxy1  <- c("Temperature (°C)","NO3","PO4","Chla","Oxygen (mgL-1)")
  preds_oxy2  <- c("Temperature (°C)","NO3","Chla","Oxygen (mgL-1)")
  preds_oxy3  <- c("Temperature (°C)","Oxygen (mgL-1)")
  preds_oxy4  <- c("Chla","Oxygen (mgL-1)")
  preds_oxy5  <- c("Temperature (°C)","NO3","Oxygen (mgL-1)")
  
  preds_temp  <- c("Temperature (°C)")
  preds_chl   <- c("Chla")
  preds_ct    <- c("Temperature (°C)","Chla")
  preds_nutri <- c("NO3","PO4","SiO4")
  
  f_full      <- reformulate(bt(preds_full),  response = response_var)
  f_red1      <- reformulate(bt(preds_red1),  response = response_var)
  f_red2      <- reformulate(bt(preds_red2),  response = response_var)
  f_red3      <- reformulate(bt(preds_red3),  response = response_var)
  
  f_oxy       <- reformulate(bt(preds_oxy),   response = response_var)
  f_oxy1      <- reformulate(bt(preds_oxy1),  response = response_var)
  f_oxy2      <- reformulate(bt(preds_oxy2),  response = response_var)
  f_oxy3      <- reformulate(bt(preds_oxy3),  response = response_var)
  f_oxy4      <- reformulate(bt(preds_oxy4),  response = response_var)
  f_oxy5      <- reformulate(bt(preds_oxy5),  response = response_var)
  
  
  f_temp      <- reformulate(bt(preds_temp),  response = response_var)
  f_chl       <- reformulate(bt(preds_chl),   response = response_var)
  f_chl_temp  <- reformulate(bt(preds_ct),    response = response_var)
  f_nutrients <- reformulate(bt(preds_nutri), response = response_var)
  
  models <- list(
    full     = lm(f_full,      data = data),
    red1     = lm(f_red1,      data = data),
    red2     = lm(f_red2,      data = data),
    red3     = lm(f_red3,      data = data),
    oxy      = lm(f_oxy,       data = data),
    oxy1     = lm(f_oxy1,      data = data),
    oxy2     = lm(f_oxy2,      data = data),
    oxy3     = lm(f_oxy3,      data = data),
    oxy4     = lm(f_oxy4,      data = data),
    oxy5     = lm(f_oxy5,      data = data),
    temp     = lm(f_temp,      data = data),
    chl      = lm(f_chl,       data = data),
    chl_temp = lm(f_chl_temp,  data = data),
    nutri    = lm(f_nutrients, data = data)
  )
  
  models
}
# Make summary table + delta vs full
summarise_models <- function(models, response_label) {
  tab <- do.call(rbind, Map(
    function(fit, nm) lm_stats_row(fit, response = response_label, model_name = nm),
    models, names(models)
  ))
  
  full_r2    <- tab$R2[tab$Model == "full"][1]
  full_adjR2 <- tab$adjR2[tab$Model == "full"][1]
  
  tab$delta_R2    <- full_r2    - tab$R2
  tab$delta_adjR2 <- full_adjR2 - tab$adjR2
  
  tab
}


# Fit the model sets (these use each model's own complete-case rows automatically)
mods_PBT <- fit_model_set(npp23, "PBT_z")
mods_PT  <- fit_model_set(npp23, "PT_z")

# One combined summary table
summary_PBT <- summarise_models(mods_PBT, response_label = "PBT_z")
summary_PT  <- summarise_models(mods_PT,  response_label = "PT_z")

summary_models_all <- rbind(summary_PBT, summary_PT)

# ---------------------------
# 2) Print / save
# ---------------------------
# Order models in logical progression
model_order <- c(
  "full",
  "red1","red2","red3",
  "oxy1","oxy2","oxy3","oxy4","oxy5","oxy",
  "temp","chl","chl_temp",
  "nutri"
)

summary_models_all$Model <- factor(
  summary_models_all$Model,
  levels = model_order
)

summary_models_all <- summary_models_all[
  order(summary_models_all$Response, summary_models_all$Model),
]

print(summary_models_all, row.names = FALSE)

# Save 
writexl::write_xlsx(summary_models_all, "npp23_cor2.xlsx")


#Range of chl a within each layer between ITW conditions
library(dplyr)

chl_range_layer_itw <- npp_full %>%
  group_by(Layer, ITWs) %>%
  summarise(
    min_chla = min(Chla, na.rm = TRUE),
    max_chla = max(Chla, na.rm = TRUE),
    range_chla = max_chla - min_chla,
    .groups = "drop"
  )

chl_range_layer_itw

writexl::write_xlsx(chl_range_layer_itw, "chl_range.xlsx")
