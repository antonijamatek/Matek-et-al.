#**Create violin distribution plots**

library(dplyr)
library(ggplot2)
library(tidyr)
library(stringr)

npp_env$SampleID <- paste0("row", seq_len(nrow(npp_env)))
npp_df$SampleID <- paste0("row", seq_len(nrow(npp_df)))
npp_factors$SampleID <- paste0("row", seq_len(nrow(npp_factors)))

npp_full <- npp_factors %>%
  left_join(npp_env %>% mutate(SampleID = npp_factors$SampleID),
            by = "SampleID") %>%
  left_join(npp_df %>% mutate(SampleID = npp_factors$SampleID),
            by = "SampleID")

npp_full <- npp_full %>%
  mutate(
    Layer = toupper(Layer),
    Layer = factor(Layer, levels = c("SURFACE", "THERMOCLINE", "DEEP LAYER")),
    ITWs  = factor(ITWs, levels = c("No", "Yes"))
  )

# Desired variable order
vars <- c("Temperature (°C)", "PBT_z", "PT_z", "Chla", "Oxygen (mgL-1)", "NO3", "PO4", "SiO4")

variable_labeller <- as_labeller(c(
  "Temperature (°C)" = "bold(Temp)",
  "PBT_z"            = "bold(P[T]^B~(z))",
  "PT_z"             = "bold(P[T]~(z))",
  "Chla"             = "bold(Chl~bolditalic(a))",
  "Oxygen (mgL-1)"   = "bold(O[2])",
  "NO3"              = "bold(NO[3])",
  "PO4"              = "bold(PO[4])",
  "SiO4"             = "bold(SiO[4])"
), label_parsed)

plot_df <- npp_full %>%
  select(SampleID, Layer, ITWs, z_m, all_of(vars)) %>%
  pivot_longer(all_of(vars), names_to = "Variable", values_to = "Value") %>%
  filter(!is.na(Value)) %>%
  mutate(
    Variable = factor(Variable, levels = vars),
    Layer    = factor(Layer, levels = c("SURFACE","THERMOCLINE","DEEP LAYER"))
  )
  

#ITWs shared axis for all variables
p1 <- ggplot(plot_df, aes(x = ITWs, y = Value)) + 
  #geom_violin(trim = TRUE, alpha = 0.5, na.rm = TRUE) +
  geom_boxplot(width = 0.2, alpha = 0.3, linewidth = 1.2, outlier.shape = NA, na.rm = TRUE) +
  geom_jitter(
    width = 0,
    size = 3.2,
    alpha = 0.8,
    na.rm = TRUE
  ) +
  facet_grid(
    Variable ~ Layer,
    scales = "free_y",
    switch = "y",
    labeller = labeller(Variable = variable_labeller)
  ) +
  labs(y = NULL, x = "ITW") +
  theme_bw(base_size = 20) +   # base font size
  theme(
    legend.position = "none",
    strip.placement = "outside",
    
    # Axis text (numbers + Yes/No)
    axis.text.x = element_text(size = 24, face = "bold"),
    axis.text.y = element_text(size = 24, face = "bold"),
    
    # Axis titles
    axis.title.x = element_text(size = 24, face = "bold"),
    axis.title.y = element_text(size = 24, face = "bold"),
    
    # Facet strip titles (rows + columns)
    strip.text = element_text(size = 22, face = "bold"),
    
    # Optional: make strip background cleaner
    strip.background = element_rect(fill = "grey90", colour = "black")
  )


p1

ggsave(
  filename = "facet_wrap_ITWs-NOVO RAD_20260828.pdf",
  plot = p1,
  width = 14,
  height = 12,
  dpi = 300,
  units = "in"
)

ggsave(
  filename = "facet_wrap_ITWs-NOVO RAD_20260828.tif",
  plot = p1,
  width = 14,
  height = 12,
  dpi = 300,
  units = "in"
)

#ITWs shown for each layer and variable separately
vars2 <- c("Temperature (°C)", "PBT_z", "PT_z", "Chla", "Oxygen (mgL-1)")


plot_df2 <- plot_df %>%
  filter(Variable %in% vars2) %>%
  mutate(
    Variable = factor(
      Variable,
      levels = vars2,
      labels = c(
        "Temperature",
        "PB_T(z)",
        "P_T(z)",
        "Chl a",
        "Oxygen"
      )
    )
  )


p2 <- ggplot(plot_df2, aes(x = ITWs, y = Value, fill = ITWs)) +
  geom_violin(trim = TRUE, alpha = 0.5, na.rm = TRUE) +
  geom_boxplot(width = 0.12, outlier.shape = NA, na.rm = TRUE) +
  facet_grid(
    Variable ~ Layer,
    scales = "free_y",
    switch = "y"
  ) +
  labs(y = NULL, x = "ITW") +
  theme_bw(base_size = 16) +   # base font size
  theme(
    legend.position = "none",
    strip.placement = "outside",
    
    # Axis text (numbers + Yes/No)
    axis.text.x = element_text(size = 18),
    axis.text.y = element_text(size = 18),
    
    # Axis titles
    axis.title.x = element_text(size = 18, face = "bold"),
    axis.title.y = element_text(size = 18, face = "bold"),
    
    # Facet strip titles (rows + columns)
    strip.text = element_text(size = 16, face = "bold"),
    
    # Optional: make strip background cleaner
    strip.background = element_rect(fill = "grey90", colour = "black")
  )

p2

ggsave(
  filename = "facet_wrap_ITWs1.pdf",
  plot = p2,
  width = 14,
  height = 10,
  dpi = 300,
  units = "in"
)

vars3 <- c("NO3", "PO4", "SiO4")
plot_df3 <- plot_df %>%
  filter(Variable %in% vars3)

p3 <- ggplot(plot_df3, aes(x = ITWs, y = Value, fill = ITWs)) +
  geom_violin(trim = TRUE, alpha = 0.5, na.rm = TRUE) +
  geom_boxplot(width = 0.12, outlier.shape = NA, na.rm = TRUE) +
  facet_grid(
    Variable ~ Layer,
    scales = "free_y",
    switch = "y"
  ) +
  labs(y = NULL, x = "ITWs") +
  theme_bw(base_size = 16) +   # base font size
  theme(
    legend.position = "none",
    strip.placement = "outside",
    
    # Axis text (numbers + Yes/No)
    axis.text.x = element_text(size = 18),
    axis.text.y = element_text(size = 18),
    
    # Axis titles
    axis.title.x = element_text(size = 18, face = "bold"),
    axis.title.y = element_text(size = 18, face = "bold"),
    
    # Facet strip titles (rows + columns)
    strip.text = element_text(size = 16, face = "bold"),
    
    # Optional: make strip background cleaner
    strip.background = element_rect(fill = "grey90", colour = "black")
  )
p3

ggsave(
  filename = "facet_wrap_ITWs2.pdf",
  plot = p3,
  width = 14,
  height = 10,
  dpi = 300,
  units = "in"
)


# All variables by layer
variable_labeller2 <- as_labeller(c(
  "Temperature (°C)" = "bold(Temperature)",
  "PBT_z"            = "bold(P[T]^B~(z))",
  "PT_z"             = "bold(P[T]~(z))",
  "Chla"             = "bold(Chl~bolditalic(a))",
  "Oxygen (mgL-1)"   = "bold(O[2])",
  "NO3"              = "bold(NO[3])",
  "PO4"              = "bold(PO[4])",
  "SiO4"             = "bold(SiO[4])"
), label_parsed)


p4 <- ggplot(plot_df, aes(x = Layer, y = Value)) +
  geom_boxplot(width = 0.2, linewidth = 1.4, outlier.shape = NA, na.rm = TRUE) +
  geom_jitter(
    width = 0,
    size = 5,
    alpha = 0.8,
    na.rm = TRUE
  ) +
  #geom_violin(trim = TRUE, alpha = 0.6, na.rm = TRUE, linewidth = 0.6) +
  #geom_boxplot(width = 0.12, outlier.shape = NA, na.rm = TRUE, linewidth = 0.8) +
  facet_wrap(~ Variable, scales = "free", labeller = labeller(Variable = variable_labeller2)) +
  #scale_fill_manual(values = c(
  #  "SURFACE"      = "gray70",
   # "THERMOCLINE"  = "red",
  #"  "DEEP LAYER"   = "lightblue"
  #)) +
 # scale_color_manual(values = c(
  #  "SURFACE"      = "black",
   # "THERMOCLINE"  = "black",
    #"DEEP LAYER"   = "black"
  #)) +
  labs(x = NULL, y = NULL) +
  theme_bw(base_size = 40) +
  theme(
    legend.position = "none",
    
    # Axis text (tick labels)
    axis.text.x = element_text(size = 35, face = "bold"),
    axis.text.y = element_text(size = 35, face = "bold"),
    
    # Axis titles
    axis.title.x = element_text(size = 35, face = "bold"),
    axis.title.y = element_text(size = 35, face = "bold"),
    
    # Facet titles
    strip.text = element_text(size = 40, face = "bold"),
    
    # Slightly stronger panel borders for balance
    panel.border = element_rect(linewidth = 1),
    axis.line = element_line(linewidth = 0.8)
  )

p4

ggsave(
  filename = "facet_wrap_layers - NOVO RAD_20260825.pdf",
  plot = p4,
  width = 38,
  height = 20,
  dpi = 300,
  units = "in"
)

ggsave(
  filename = "facet_wrap_layers - NOVO RAD_20260825.tif",
  plot = p4,
  width = 38,
  height = 20,
  dpi = 300,
  units = "in"
)

npp_full

