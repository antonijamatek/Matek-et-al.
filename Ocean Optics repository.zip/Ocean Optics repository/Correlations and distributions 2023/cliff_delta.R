source("C:/Users/Tihomir/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza/Data_coherence_I_II_III/Correlation/packages.R")


# Packages
library(dplyr)
library(tidyr)
library(ggplot2)
library(effsize)   # cliff.delta()

# --- 1) Variables to test (exactly as in your df)
vars <- c("Temperature (°C)", "PBT_z", "PT_z", "Chla",
          "Oxygen (mgL-1)", "NO3", "PO4", "SiO4")

layers <- c("SURFACE", "THERMOCLINE", "DEEP LAYER")

# --- 2) Function: Cliff's delta (ITW Yes vs No) within a layer
# Interpretation here: positive δ means values in ITW(Yes) tend to be higher than No
compare_itw <- function(df, var_name, layer_name) {
  
  x_yes <- df %>%
    filter(ITWs == "Yes", Layer == layer_name) %>%
    pull(.data[[var_name]]) %>%
    as.numeric()
  
  x_no <- df %>%
    filter(ITWs == "No", Layer == layer_name) %>%
    pull(.data[[var_name]]) %>%
    as.numeric()
  
  x_yes <- x_yes[is.finite(x_yes)]
  x_no  <- x_no[is.finite(x_no)]
  
  # handle tiny groups safely
  if (length(x_yes) < 2 || length(x_no) < 2) {
    return(tibble(
      variable = var_name, layer = layer_name,
      n_itw = length(x_yes), n_noitw = length(x_no),
      cliff_delta = NA_real_
    ))
  }
  
  cd <- effsize::cliff.delta(x_yes, x_no)  # Yes vs No
  
  tibble(
    variable = var_name,
    layer = layer_name,
    n_itw = length(x_yes),
    n_noitw = length(x_no),
    median_itw = median(x_yes, na.rm = TRUE),
    median_noitw = median(x_no, na.rm = TRUE),
    cliff_delta = unname(cd$estimate),
    cliff_low = cd$conf.int[1],
    cliff_high = cd$conf.int[2]
  )
}

# --- 3) Apply across all variables & layers
cliff_results <- expand.grid(var = vars, layer = layers, stringsAsFactors = FALSE) %>%
  rowwise() %>%
  do(compare_itw(npp_full, .$var, .$layer)) %>%
  ungroup() %>%
  mutate(
    layer = factor(layer, levels = layers),
    variable = factor(variable, levels = vars)
  )

cliff_results

# --- 4) Plot: heatmap of Cliff's delta
p_cliff_itw <- ggplot(cliff_results, aes(x = variable, y = layer, fill = cliff_delta)) +
  geom_tile(color = "white", linewidth = 0.4) +
  scale_fill_gradient2(
    low = "#2166ac",
    mid = "white",
    high = "#b2182b",
    midpoint = 0,
    limits = c(-1, 1),
    name = "Cliff's δ\n(ITW Yes vs No)"
  ) +
  labs(x = NULL, y = NULL, title = "ITW vs non-ITW distributional differences (Cliff’s delta)") +
  theme_bw() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    panel.grid = element_blank(),
    plot.title = element_text(size = 12, face = "bold")
  )

p_cliff_itw

ggsave(
  filename = "cliff_delta_ITW_vs_NoITW.jpg",
  plot = p_cliff_itw,
  width = 14, height = 7, dpi = 300, units = "in"
)


# Filter only Surface and Thermocline
cliff_results_plot <- cliff_results %>%
  filter(layer %in% c("SURFACE", "THERMOCLINE")) %>%
  mutate(
    layer = factor(layer, levels = c("SURFACE", "THERMOCLINE"))
  )

# Plot
p_cliff_itw <- ggplot(cliff_results_plot,
                      aes(x = variable, y = layer, fill = cliff_delta)) +
  geom_tile(color = "white", linewidth = 0.4) +
  scale_fill_gradient2(
    low = "#2166ac",
    mid = "white",
    high = "#b2182b",
    midpoint = 0,
    limits = c(-1, 1),
    name = "Cliff's δ\n(ITW Yes vs No)"
  ) +
  labs(
    x = NULL,
    y = NULL,
    title = "ITW vs non-ITW distributional differences (Cliff’s delta)"
  ) +
  theme_bw() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    panel.grid = element_blank(),
    plot.title = element_text(size = 12, face = "bold")
  )

p_cliff_itw

ggsave(
  filename = "cliff_delta_ITW_vs_NoITW.pdf",
  plot = p_cliff_itw,
  width = 14, height = 7, dpi = 300, units = "in"
)


