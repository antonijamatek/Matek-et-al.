library("vegan")
library("dplyr")
library("readr")
library("ggvegan")
library("ggrepel")
library("ggplot2")
library("tibble")


npp_df <- readxl::read_xlsx("C:/Users/Tihomir/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza/Data_coherence_I_II_III/CCA_NPP/npp.xlsx")
npp_factors <- readxl::read_xlsx("C:/Users/Tihomir/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza/Data_coherence_I_II_III/CCA_NPP/nppfactors.xlsx")
npp_env <- readxl::read_xlsx("C:/Users/Tihomir/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza/Data_coherence_I_II_III/CCA_NPP/environment_23.xlsx")

#**PROJECT NPP to 2021-2022 ENVIRONMENT (CCA MODEL) TO PREDICT LC SCORES  FOR 2023**
#**TO CORRELATE THE 2023 NPP TO CCA GRADIENT**
#**THIS IS BASED ON DATA COHERENCE - COMPARING 2023 NPP TO 2021-2022 ECOSYSTEM STATE ALTHOUGH NOT MEASURED CONCURRENTLY*

#**1. Prepare data*

# log transforming environment data (ONLY numeric environmental columns)

env_vars <- c(
  "NO3",
  "PO4",
  "SiO4",
  "Temperature (°C)",
  "Chla",
  "Oxygen (mgL-1)"
)

npp_env. <- npp_env %>%
  mutate(across(all_of(env_vars), ~ log1p(.x)))

# standardize environmental data (ONLY env vars, keep names)
npp_env. <- npp_env. %>%
  mutate(across(all_of(env_vars), ~ as.numeric(scale(.x))))

dim(npp_env.)

# create df for the model
npp23 <- cbind(npp_env., npp_df)
npp23$SampleID <- paste0("row", seq_len(nrow(npp23)))

# use EXACT column names
env23 <- npp23[, c("SampleID", env_vars)]

keep <- complete.cases(env23[, env_vars])
env23_1 <- env23[keep, , drop = FALSE]

env <- env23_1[, env_vars, drop = FALSE]
rownames(env) <- env23_1$SampleID

#**2. Function to project lc for 2023 based on 2021 and 2022 cca models*
project_lc <- function(cca_model, new_env, axes = 1:2, label = "model") {
  # new_env = data.frame/tibble with EXACT variable names used in cca_model
  # (NO3, PO4, SiO4, Temperature, Chla)
  
  pred <- predict(cca_model, newdata = new_env, type = "lc", scaling = 2)
  # pred is a matrix with columns like CCA1, CCA2, ...
  
  out <- as.data.frame(pred)[, paste0("CCA", axes), drop = FALSE]
  out$SampleID <- rownames(pred) %||% paste0("row", seq_len(nrow(out)))
  out$model <- label
  out
}


#**3. Apply and get summary of regression*

#**Prepare input parameters*

#a) Load CCA model from other R environment*
load("cca21.RData") #full model including nutrients, temperature, and chlorophyll
load("cca22.RData")

load("cca21_2.RData") #reduced model to only nutrients and temperature
load("cca22_2.RData")

load("cca21_3.RData") #Reduced model to only chlorophyll
load("cca22_3.RData")

#b) Here you choose which CCA model to run (imported from other script)*
a <- cca21m 

#c) Define x aand y in the predicting CCA model (must match imported CCA model)
x <- npp_df
y <- env

#d) Predict and create dataframe for regression and plots
lc23 <- predict(a, newdata = y, type = "lc", scaling = 2)
lc23_df <- data.frame(lc23, SampleID = rownames(lc23), row.names = NULL)
analysis_df <- merge(npp23, lc23_df, by = "SampleID", all.x = TRUE) #**merge predicted LC scores with original npp data*

#Plot if you wish
plot(analysis_df$CCA1, analysis_df$PT_z,
     pch = 16,
     xlab = "Predicted CCA1 (2021 micro/nano space)",
     ylab = "PT_z (2023)")
abline(lm(PT_z ~ CCA1, data = analysis_df), col = "red")

plot(analysis_df$CCA1, analysis_df$PBT_z,
     pch = 16,
     xlab = "Predicted CCA1 (2021 micro/nano space)",
     ylab = "PBT_z (2023)")
abline(lm(PBT_z ~ CCA1, data = analysis_df), col = "red")

#Get the results of regression
summary(lm(PT_z ~ CCA1, data = analysis_df))
summary(lm(PBT_z ~ CCA1, data = analysis_df))


#Automate and ave results in 4 tables

# ----------------------------
# 1) Put ALL CCA models in one named list
# ----------------------------
cca_models <- list(
  # 2021 Micro/Nano
  "2021_MicroNano_Full"        = cca21m,
  "2021_MicroNano_Reduced_env" = cca21m2,
  "2021_MicroNano_Chl_only"    = cca21m3,
  
  # 2021 Pico
  "2021_Pico_Full"             = cca21p,
  "2021_Pico_Reduced_env"      = cca21p2,
  "2021_Pico_Chl_only"         = cca21p3,
  
  # 2022 Micro/Nano
  "2022_MicroNano_Full"        = cca22m,
  "2022_MicroNano_Reduced_env" = cca22m2,
  "2022_MicroNano_Chl_only"    = cca22m3,
  
  # 2022 Pico
  "2022_Pico_Full"             = cca22p,
  "2022_Pico_Reduced_env"      = cca22p2,
  "2022_Pico_Chl_only"         = cca22p3
)

# ----------------------------
# 2) Helper: pull env variable names required by a cca model
#    (so we can filter complete cases only for those vars)
# ----------------------------
get_env_vars <- function(cca_model) {
  # works for vegan::cca
  # term labels are the RHS variables in the formula
  attr(terms(cca_model), "term.labels")
}

# ----------------------------
# 3) Helper: extract stats from lm
# ----------------------------
extract_lm_stats <- function(model, response_name) {
  s <- summary(model)
  f <- s$fstatistic
  
  data.frame(
    Response = response_name,
    R2       = unname(s$r.squared),
    adjR2    = unname(s$adj.r.squared),
    F        = unname(f[1]),
    df1      = unname(f[2]),
    df2      = unname(f[3]),
    p_value  = pf(f[1], f[2], f[3], lower.tail = FALSE),
    
    stringsAsFactors = FALSE
  )
}

# ----------------------------
# 4) Core runner: predict LC scores + regressions for one cca model
# ----------------------------
run_one_model <- function(cca_model, model_id, env_df, npp23_df) {
  
  env_vars <- get_env_vars(cca_model)
  
  # keep only rows with complete env needed for this model
  keep <- complete.cases(env_df[, env_vars, drop = FALSE])
  
  env_use <- env_df[keep, env_vars, drop = FALSE]
  # Ensure rownames exist & match SampleID for merge
  # Assumption: env_df has rownames = SampleID (like you prepared earlier)
  sid_use <- rownames(env_df)[keep]
  rownames(env_use) <- sid_use
  
  # Predict LC (site) scores
  lc <- predict(cca_model, newdata = env_use, type = "lc", scaling = 2)
  lc_df <- data.frame(lc, SampleID = rownames(lc), row.names = NULL)
  
  # Merge with npp23 (keeps PT_z/PBT_z etc.)
  analysis_df <- merge(npp23_df, lc_df, by = "SampleID", all.x = FALSE)
  
  # Regressions
  m_PT  <- lm(PT_z  ~ CCA1, data = analysis_df)
  m_PBT <- lm(PBT_z ~ CCA1, data = analysis_df)
  
  out <- rbind(
    extract_lm_stats(m_PT,  "PT_z"),
    extract_lm_stats(m_PBT, "PBT_z")
  )
  
  # Parse model_id => Year, Community, Model
  parts <- strsplit(model_id, "_")[[1]]
  Year      <- parts[1]
  Community <- parts[2]
  Model     <- paste(parts[3:length(parts)], collapse = "_")  # Full / Reduced_env / Chl_only
  
  out$Year      <- Year
  out$Community <- Community
  out$Model     <- Model
  out$ModelID   <- model_id
  
  out
}

# ----------------------------
# 5) Run EVERYTHING
#    IMPORTANT: env must have rownames = SampleID
# ----------------------------
# If you don't already have this, do it once:
# rownames(env) <- env23_1$SampleID   # or whatever object you used
# (Based on your earlier steps, you already had rownames(env) set.)

all_results <- do.call(
  rbind,
  lapply(names(cca_models), function(id) {
    run_one_model(
      cca_model = cca_models[[id]],
      model_id  = id,
      env_df    = env,
      npp23_df  = npp23
    )
  })
)

# ----------------------------
# 6) Compute delta R2 / delta adjR2 relative to FULL within each group
# ----------------------------
all_results <- all_results %>%
  group_by(Year, Community, Response) %>%
  mutate(
    R2_full    = R2[Model == "Full"][1],
    adjR2_full = adjR2[Model == "Full"][1],
    delta_R2   = R2_full - R2,
    delta_adjR2 = adjR2_full - adjR2
  ) %>%
  ungroup() %>%
  select(Response, R2, adjR2, F, df1, df2, p_value, Model, delta_R2, delta_adjR2, Year, Community, ModelID)

# ----------------------------
# 7) Split into 4 tables (exactly as you wanted)
# ----------------------------
table_21m <- all_results %>% filter(Year == "2021", Community == "MicroNano") %>% select(-ModelID)
table_21p <- all_results %>% filter(Year == "2021", Community == "Pico")      %>% select(-ModelID)
table_22m <- all_results %>% filter(Year == "2022", Community == "MicroNano") %>% select(-ModelID)
table_22p <- all_results %>% filter(Year == "2022", Community == "Pico")      %>% select(-ModelID)

# Optional: print
table_21m
table_21p
table_22m
table_22p

#Save table
writexl::write_xlsx(table_21m, "cca_npp_21m.xlsx")
writexl::write_xlsx(table_21p, "cca_npp_21p.xlsx")
writexl::write_xlsx(table_22m, "cca_npp_22m.xlsx")
writexl::write_xlsx(table_22p, "cca_npp_22p.xlsx")


library(dplyr)

bind_rows(
  table_21m %>% mutate(Year = 2021, Community = "MicroNano"),
  table_21p %>% mutate(Year = 2021, Community = "Pico"),
  table_22m %>% mutate(Year = 2022, Community = "MicroNano"),
  table_22p %>% mutate(Year = 2022, Community = "Pico")
) -> final_delta_table

writexl::write_xlsx(final_delta_table, "cca_npp_all.xlsx")
