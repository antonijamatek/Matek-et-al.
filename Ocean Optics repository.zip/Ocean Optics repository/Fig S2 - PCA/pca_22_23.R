source("C:/Users/Antonija/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza/Experiment II i III/Statistics/packages.R")
library(tidyr)
library(dplyr)
library(ggrepel)


df <- readxl::read_xlsx("C:/Users/Antonija/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza/Experiment II i III/Statistics/PCA_percentage_change_novo_itw/pca_22_23.xlsx")
df <- df %>%
  mutate(
    Layer = toupper(Layer),
    Layer = factor(Layer, levels = c("SURFACE", "THERMOCLINE", "DEEP LAYER"))
  )


df_factors <- df[c(1:2, 12:13)]
df_pca <- df[-c(1:2, 12:13)]


#preform PCA for 2022 and 2023 
df_pca_sub <- df_pca %>%
  select(`PT _z`, PBT_Z, Temp, Chla, Oxygen)
df

pca <- rda(df_pca_sub, scale = TRUE)
summary(pca)


#######################PLOTTING GGVEGAN########################

#Fortifying the ordination that will be plotted with ggvegan package
#The convention with ggplot2 is to `fortify()` the object we wish to plot, 
#which basically means turn the object into a format that is suitable for plotting with `ggplot()`
ford <- fortify(pca, axes = 1:2, scaling = "symmetric")
ford <- as_tibble(ford)
ford
names(ford)[3:4] <- c("PC1", "PC2")
species <- fortify(pca,axes = 1:2,scaling = "symmetric",layers = "sp")
names(species)[3:4] <- c("PC1", "PC2")
sites <- fortify(pca,axes = 1:2,scaling = "symmetric",layers = "wa")
names(sites)[3:4] <- c("PC1", "PC2")
sites <- sites %>%
  bind_cols(df_factors)   # add factors


#graphic info
vignette("ggplot2-specs")#graphics info
?pch #graphics info
cols <- c("blue", "black", "red") #defining colors for ggplot points


##############NO NUTRIENTS ######################
#plot 2022 and 2023 with factor station and layer
p <- ggplot(ford, aes(x = PC1, y = PC2)) +
  geom_hline(yintercept = 0, colour = "black", alpha = 1) +
  geom_vline(xintercept = 0, colour = "black", alpha = 1) + 
  geom_point(data = sites, 
             mapping = aes(colour = Layer), size = 2.8) +
  scale_color_manual(values = cols) +
  geom_point(data = sites, 
             mapping = aes(shape = Station), size = 4, stroke = 1.1) +
  scale_shape_manual(values = c(0,1,2,3,4,5)) +
  geom_label(data = species, aes(label = label), label.size = 0.4, cex = 4) +
  geom_segment(data = filter(ford, score == "species"),
               mapping = aes(x = 0, y = 0, xend = PC1 * 0.7, yend = PC2 * 0.7),
               arrow = arrow(length = unit(0.4, "cm"))) + 
  
  ggtitle("PCA 2022 and 2023") + 
  theme_bw()+
  theme(
    panel.grid.major = element_blank(),  # removes major grid lines
    panel.grid.minor = element_blank()   # removes minor grid lines
  ) +
  theme(legend.title = element_blank(),
        axis.text.y = element_text(size = rel(2), angle = 0),
        axis.text.x = element_text(size = rel(2), angle = 0),
        axis.title.y = element_text(size = rel(1.5), angle = 90),
        axis.title.x = element_text(size = rel(1.5), angle = 0))+
  labs(x = "PC1 ()", y = "PC2 ()")

p

#plot 2022 and 2023 with factor ITWs and layer
p1 <- ggplot(ford, aes(x = PC1, y = PC2)) +
  geom_hline(yintercept = 0, colour = "black", alpha = 1) +
  geom_vline(xintercept = 0, colour = "black", alpha = 1) + 
  geom_point(data = sites, 
             mapping = aes(colour = Layer), size = 2.8) +
  scale_color_manual(values = cols) +
  geom_point(data = sites, 
             mapping = aes(shape = ITWs), size = 4, stroke = 1.1) +
  scale_shape_manual(values = c(0,1)) +
  geom_label(data = species, aes(label = label), label.size = 0.4, cex = 4) +
  geom_segment(data = filter(ford, score == "species"),
               mapping = aes(x = 0, y = 0, xend = PC1 * 0.7, yend = PC2 * 0.7),
               arrow = arrow(length = unit(0.4, "cm"))) + 

  ggtitle("PCA 2022 and 2023") + 
  theme_bw()+
  theme(
    panel.grid.major = element_blank(),  # removes major grid lines
    panel.grid.minor = element_blank()   # removes minor grid lines
  ) +
  theme(legend.title = element_blank(),
        axis.text.y = element_text(size = rel(2), angle = 0),
        axis.text.x = element_text(size = rel(2), angle = 0),
        axis.title.y = element_text(size = rel(1.5), angle = 90),
        axis.title.x = element_text(size = rel(1.5), angle = 0))+
  labs(x = "PC1 ()", y = "PC2 ()")

p1


#2022 only
#ITWs and layer
df_2022 <- df %>%
  filter(grepl("22\\.$", Date)) %>%
  select(Station, Date, z, `PT _z`, PBT_Z, Temp, Chla, Oxygen,
         Layer, ITWs)

factors <- df_2022[c(1:3, 9:10)]

cols <- c(
  "SURFACE"     = "black",
  "THERMOCLINE" = "red",
  "DEEP LAYER"  = "blue"
)

pca <- rda(df_2022[,c("PT _z","PBT_Z","Temp","Chla","Oxygen")],
           scale = TRUE)

summary(pca)

ford <- fortify(pca, axes = 1:2, scaling = "symmetric")
ford <- as_tibble(ford)
ford
names(ford)[3:4] <- c("PC1", "PC2")
species <- fortify(pca,axes = 1:2,scaling = "symmetric",layers = "sp")
names(species)[3:4] <- c("PC1", "PC2")
sites <- fortify(pca,axes = 1:2,scaling = "symmetric",layers = "wa")
names(sites)[3:4] <- c("PC1", "PC2")
sites <- sites %>%
  bind_cols(factors)   # add factors

p3 <- ggplot(ford, aes(x = PC1, y = PC2)) +
  geom_hline(yintercept = 0, colour = "black") +
  geom_vline(xintercept = 0, colour = "black") +
  geom_point(
    data = sites,
    aes(colour = Layer),
    size = 2.8
  ) +
  scale_color_manual(values = cols) +
  geom_point(
    data = sites,
    aes(shape = ITWs),
    size = 4,
    stroke = 1.1
  ) +
  scale_shape_manual(values = c("ITW" = 0, "No ITW" = 1)) +
  geom_label(data = species, aes(label = label), label.size = 0.4, cex = 6) +
  geom_segment(
    data = filter(ford, score == "species"),
    aes(x = 0, y = 0, xend = PC1 * 0.7, yend = PC2 * 0.7),
    arrow = arrow(length = unit(0.4, "cm"))
  ) +
  ggtitle("June 2022") +
  theme_bw() +
  theme(
    plot.title = element_text(
      size = 20,
      face = "bold"
    ),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    legend.title = element_blank(),
    axis.text.y = element_text(size = rel(2)),
    axis.text.x = element_text(size = rel(2)),
    axis.title.y = element_text(size = rel(1.5), angle = 90),
    axis.title.x = element_text(size = rel(1.5))
  ) +
  labs(x = "PC1 (63.04%)", y = "PC2 (21.25%)")

p3 <- p3 +
  geom_text_repel(
    data = sites,
    aes(label = Station),
    size = 5,
    max.overlaps = Inf
  )

p3

#2023 only 
#itws and layer

df_2023 <- df %>%
  filter(grepl("23\\.$", Date))

df_2023 <- df_2023 %>%
  mutate(
    PO4 = ifelse(is.na(PO4), 0, PO4)
  )


factors <- df_2023[c(1:3, 12:13)]

cols <- c(
  "SURFACE"     = "black",
  "THERMOCLINE" = "red",
  "DEEP LAYER"  = "blue"
)

pca <- rda(df_2023[,c("PT _z","PBT_Z","Chla", "Temp", "Oxygen", "PO4", "SiO4", "NO3")],
           scale = TRUE)
summary(pca)

ford <- fortify(pca, axes = 1:2, scaling = "symmetric")
ford <- as_tibble(ford)
ford
names(ford)[3:4] <- c("PC1", "PC2")
species <- fortify(pca,axes = 1:2,scaling = "symmetric",layers = "sp")
names(species)[3:4] <- c("PC1", "PC2")
sites <- fortify(pca,axes = 1:2,scaling = "symmetric",layers = "wa")
names(sites)[3:4] <- c("PC1", "PC2")
sites <- sites %>%
  bind_cols(factors)   # add factors


p4 <- ggplot(ford, aes(x = PC1, y = PC2)) +
  geom_hline(yintercept = 0, colour = "black") +
  geom_vline(xintercept = 0, colour = "black") +
  geom_point(
    data = sites,
    aes(colour = Layer),
    size = 2.8
  ) +
  scale_color_manual(values = cols) +
  geom_point(
    data = sites,
    aes(shape = ITWs),
    size = 4,
    stroke = 1.1
  ) +
  scale_shape_manual(values = c("ITW" = 0, "No ITW" = 1)) +
  geom_label(data = species, aes(label = label), label.size = 0.4, cex = 6) +
  geom_segment(
    data = filter(ford, score == "species"),
    aes(x = 0, y = 0, xend = PC1 * 0.7, yend = PC2 * 0.7),
    arrow = arrow(length = unit(0.4, "cm"))
  ) +
  ggtitle("July 2023") +
  theme_bw() +
  theme(    
    plot.title = element_text(
    size = 20,
    face = "bold"
    ),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    legend.title = element_blank(),
    axis.text.y = element_text(size = rel(2)),
    axis.text.x = element_text(size = rel(2)),
    axis.title.y = element_text(size = rel(1.5), angle = 90),
    axis.title.x = element_text(size = rel(1.5))
  ) +
  labs(x = "PC1 (41.6%)", y = "PC2 (16.5%)")


p4 <- p4 +
  geom_text_repel(
    data = sites,
    aes(label = Station),
    size = 5,
    max.overlaps = Inf
  )

p4



#Final image for paper

library(cowplot)

# extract one shared legend from p3
shared_legend <- cowplot::get_legend(
  p3 +
    theme(
      legend.position = "right",
      legend.title = element_blank(),
      legend.text = element_text(size = 14)
    )
)

# remove legends from both plots
p3_noleg <- p3 +
  theme(legend.position = "none")

p4_noleg <- p4 +
  theme(legend.position = "none")

# stack PCA plots vertically
p_pca <- cowplot::plot_grid(
  p3_noleg,
  p4_noleg,
  ncol = 1,
  labels = c("A", "B"),
  label_size = 20,
  label_fontface = "bold",
  align = "v"
)

# final plot with one shared legend on the right
p_final <- cowplot::plot_grid(
  p_pca,
  shared_legend,
  ncol = 2,
  rel_widths = c(1, 0.18)
)

p_final

ggsave(
  "PCA_2022_2023_combined.pdf",
  p_final,
  width = 12,
  height = 11,
  units = "in",
  dpi = 300
)

ggsave(
  "PCA_2022_2023_combined.tif",
  p_final,
  width = 12,
  height = 11,
  units = "in",
  dpi = 300
)



#percentage change
