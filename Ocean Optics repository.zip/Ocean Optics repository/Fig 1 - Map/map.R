library(ggplot2)
library(marmap)
library(patchwork)
library(ggOceanMaps)
library(ggrepel)
library(RColorBrewer)
library(scales)
library(cowplot)
library(ggspatial)
library(grid)

par(mar = c(3,4,2,2))
display.brewer.all()

# Define bounding boxes for the maps
south_adriatic_bbox <- data.frame(lon = c(16.5, 18.5), lat = c(41.5, 43.5))
lastovo_korcula_bbox <- data.frame(lon = c(16.5, 17.2), lat = c(42.6, 43))

# Fetch bathymetry data
bathy_south_adriatic <- getNOAA.bathy(
  lon1 = 16.5, lon2 = 18.5,
  lat1 = 41.5, lat2 = 43.5,
  resolution = 0.05
)

bathy_lastovo_korcula <- getNOAA.bathy(
  lon1 = 16.5, lon2 = 17.2,
  lat1 = 42.6, lat2 = 43,
  resolution = 0.05
)

# Convert bathymetry data to dataframes
bat_south <- as.data.frame(as.xyz(bathy_south_adriatic))
bat_lastovo <- as.data.frame(as.xyz(bathy_lastovo_korcula))

colnames(bat_south) <- c("lon", "lat", "depth")
colnames(bat_lastovo) <- c("lon", "lat", "depth")

# Define study locations
locations <- data.frame(
  lon = c(16.82483, 16.82697, 16.86121, 16.88753),
  lat = c(42.89504, 42.78021, 42.72624, 42.72289),
  site = c("P4", "M1", "S0", "S1")
)

# Color palette for the larger map
color_palette1 <- scale_fill_gradientn(
  colors = rev(brewer.pal(11, "YlGnBu")),
  values = rescale(c(-1300, -1000, -800, -600, -300, -100, 0)),
  name = "(m)",
  limits = c(-1300, 0)
)

# Color palette for the smaller map
color_palette2 <- scale_fill_gradientn(
  colors = rev(brewer.pal(11, "YlGnBu")),
  values = rescale(c(-200, -150, -100, -50, 0)),
  name = "(m)",
  limits = c(-200, 0)
)

# General plotting function with scale bar + north arrow
plot_bathymetry <- function(data, palette, sites = NULL, contour_bins = 10) {
  
  p <- ggplot() +
    geom_tile(
      data = data,
      aes(x = lon, y = lat),
      fill = "gray",
      show.legend = FALSE
    ) +
    geom_tile(
      data = subset(data, depth < 0),
      aes(x = lon, y = lat, fill = depth)
    ) +
    geom_contour(
      data = data,
      aes(x = lon, y = lat, z = depth),
      color = "gray30",
      bins = contour_bins
    ) +
    palette +
    xlab("Longitude") +
    ylab("Latitude") +
    coord_quickmap() +
    theme_minimal(base_size = 20) +
    theme(
      legend.position = "bottom",
      legend.direction = "horizontal",
      legend.box = "horizontal",
      legend.key.width = unit(2, "cm"),
      legend.box.spacing = unit(0.5, "cm")
    ) +
    
    # SCALE BAR
    annotation_scale(
      location = "bl",
      width_hint = 0.25,
      pad_x = unit(0.3, "cm"),
      pad_y = unit(0.3, "cm"),
      text_cex = 0.9,
      line_width = 0.8,
      plot_unit = "km"
    ) +
    
    # NORTH ARROW
    annotation_north_arrow(
      location = "tr",
      which_north = "true",
      pad_x = unit(0.3, "cm"),
      pad_y = unit(0.3, "cm"),
      style = north_arrow_fancy_orienteering(
        text_size = 10,
        line_width = 0.8
      ),
      height = unit(1.0, "cm"),
      width = unit(1.0, "cm")
    )
  
  if (!is.null(sites)) {
    p <- p +
      geom_point(
        data = sites,
        aes(x = lon, y = lat),
        color = "black",
        size = 3
      ) +
      geom_text_repel(
        data = sites,
        aes(x = lon, y = lat, label = site),
        color = "black",
        size = 5
      )
  }
  
  return(p)
}

# Generate maps
south_adriatic_map <- plot_bathymetry(
  data = bat_south,
  palette = color_palette1,
  contour_bins = 20
)

lastovo_korcula_map <- plot_bathymetry(
  data = bat_lastovo,
  palette = color_palette2,
  sites = locations,
  contour_bins = 5
)

# Combine maps
combined_map <- cowplot::plot_grid(
  south_adriatic_map,
  lastovo_korcula_map,
  ncol = 2,
  labels = c("A", "B"),
  label_size = 18
)

combined_map
