source("C:/Users/Antonija/OneDrive - Prirodoslovno-matematički fakultet//Doktorat/Obrada podataka/Light_model/2023/packages.R")
library(plotly)

#set the locale to English for time-related operations
Sys.setlocale("LC_TIME", "C")

load("isotherm_23_edited.RData")
load("K_int23.Rdata")

isotherm <- isotherm_filtered
remove(isotherm_filtered)

K_int <- K_int[!grepl("00:00:00", K_int$TimeStamp), ]
isotherm <- isotherm[!grepl("00:00:00", isotherm$TimeStamp), ]
time <- isotherm$TimeStamp

#**ITW1 06, 07, 08 July*
 
#WEEK 07. - 13. July (i par dana poslije jer nemam dva dana prije ITW in situ podatke za temperaturu)
#force it to start at the midnight
isotherm2 <- isotherm[145:2153,]
K_int2 <- K_int[145:2153,]
time2 <- time[145:2153]


#length of isotherm, time, and K_t must be the same
length(time2)
length(K_int2$Kint)
length(isotherm2$`20 °C isotherm depth (m)`)

#check the range of K_t used in analysis to put in the paper
K_int2_range <- range(K_int2$Kint, na.rm = TRUE)


#**THE FIRST PART**
#**Model surface irradiance as a function of daylength I0t*

#I0m- average monthly noon irradiance in August from The Croatian Meteorological and Hydrological Service climate atlas
#klimatski atlas hrvatske DHMZ
#Srednja mjesečna ukupna dozračena sunčeva energija za Dubrovnik, kolovoz je 800 #MJ/m2month

#konverzija u PAR (umol/m2s)
#https://www.researchgate.net/post/How_to_convert_mol_m-2s-1_to_MJ_m2_day_to_calculate_accumulated_incident_PAR_of_whole_day
I0m <- (800/31)/0.0864
#za umol/m2s wm2*4.6 
#define daylength for model
#https://www.timeanddate.com/sun/@3196754?month=8&year=2022
D <- 14

#one day has 1440 minutes, and there is 288 five minutes 
#model time vector for one day 
date <- unique(as.Date(time2, tz = "Europe/Zagreb"))
d <- length(date)
#define Nt for matrix
Nt <- length(time2)
n <- Nt/d
deltat <- 24/n
t <- seq(-5, 19, by= deltat)
I0 <- matrix(I0m * (ifelse(sin(pi*t/D) < 0, 0, sin(pi*t/D))), nrow = 1, ncol = length(t))
plot(t, I0, type = "l", lwd = 2, xlab = "Daylength", ylab = "I0 [umol/m2s]")


#replicate the model for d (once for each day in dates)
I0 <- I0[, -288]
r <-replicate(d, I0)

length(r)
Nt

#create matrix with replicates 
I0t <- matrix(r, nrow = 1, ncol = Nt)

# Plot
plot_ly(x = time2, y = as.vector(I0t), type = "scatter", mode = "lines") %>%
  layout(xaxis = list(title = "Date in 2023 [UTC+1]"),
         yaxis = list(title = "I0m * sin(pi * t/ D) [W/m2]"))


#**SECOND PART*
#**model light as a function of depth and time  I0(z,t)*

#define depths for model
depth <- seq(0, 75, by = 0.5)
#define Nz for matrix
Nz <- length(depth)
#define depth of isotherm
isotherm_depth <- isotherm2$`20 °C isotherm depth (m)`
#smooth the curve
isotherm_depth2 <- rollapply(isotherm_depth, width = 12, FUN = mean, align = "center", fill = NA)
#define K as vector
K_t <- K_int2$Kint

#initializing matrix
Izt <- matrix(NA, nrow = Nz, ncol = Nt)

#calculating
for (i in 1:Nz) {
  Izt[i,]  <- I0t * exp(-K_t * (depth[i]))
}
range(Izt, na.rm = TRUE)

#Izt[is.na(Izt)] <- -1

#plot
plot_ly(x = time2, y = -depth[1:70], z = Izt[1:70,], type = 'contour',
        contours = list(start = 0, end = 300, size = 50)) %>% 
  layout(xaxis = list(title = "Date in 2023 [UTC+1]"), yaxis = list(title = "z (m)"))%>%
  add_trace(x = time2, y = -isotherm_depth2, type = "scatter", mode = "line")


#**THE THIRD PART*
#**insert thermocline depths in model*

Izt1 <- I0t * exp(-K_t * isotherm_depth2)
range(Izt1, na.rm = TRUE)
Izt1 <- as.numeric(Izt1)

#plot
plot_ly(x = time2, y = Izt1, type = "scatter",
        mode = "lines")%>% layout(xaxis = list(title = "Date in 2023 [UTC+1]"),
                                  yaxis = list(title = "Izt  <- I0t * exp(-K * z(thermocline) [W/m2]"))


#**Insert average thermocline depth**
z_avg <- mean(isotherm_depth2, na.rm = TRUE) 
Izt2 <- I0t*exp(-K_t*z_avg)
range(Izt2, na.rm = TRUE)
Izt2 <- as.numeric(Izt2)

#plot
plot_ly(x = time2, y = as.vector(Izt2), type = "scatter",
        mode = "lines")%>% layout(xaxis = list(title = "Date in 2023 [UTC+1]"),
                                  yaxis = list(title = "Izt  <- I0t * exp(-K * z_avg(thermocline) [W/m2]"))

#PLOT BOTH - thermocline depths vs average thermocline depth
plot_ly(x = time2, y = Izt1, type = "scatter",
        mode = "lines", name = "Isotherm depths")%>% layout(xaxis = list(title = "Date in 2023 [UTC+1]"),
                                  yaxis = list(title = "I0t * exp(K * z(isotherm)) [W/m2]"))%>% 
        add_lines(x = time2, y = Izt2, type = "scatter",
                         mode = "lines", name = "Average isotherm depth")
        

#**Calculate and plot anomaly*
anomaly <- Izt1 - Izt2
anomaly <- as.numeric(anomaly)


#**FINAL PLOTS**

#**CONTOUR*
p <- plot_ly(x = time2, y = -depth[1:70], z = Izt[1:70,], type = 'contour',
             contours = list(start = 0, end = 300, size = 50),
             colorbar = list(title = "I(z,t) [W/m<sup>2</sup>]", 
                             titlefont = list(size = 35), 
                             tickfont = list(size = 35))) %>% 
  layout(xaxis = list(title = "July 2023 [UTC+1]", 
                      titlefont = list(size = 35), 
                      tickfont = list(size = 35),
                      tickformat = "%d",      
                      dtick = 24*60*60*1000),
         yaxis = list(title = "z [m]", 
                      titlefont = list(size = 35), 
                      tickfont = list(size = 35)),
         showlegend = FALSE) %>%
  add_trace(x = time2, y = -isotherm_depth2, type = "scatter", mode = "line")

p

#**SINUSOIDAL*
p1 <- plot_ly(x = time2, y = Izt1, type = "scatter", mode = "lines", name = "I(z<sub>i</sub>,t)") %>% 
  layout(xaxis = list(title = "July 2023 [UTC+1]", 
                      titlefont = list(size = 35), 
                      tickfont = list(size = 35),
                      tickformat = "%d",      
                      dtick = 24*60*60*1000),  
         yaxis = list(title = "I(z,t) [W/m<sup>2</sup>]", 
                      titlefont = list(size = 35), 
                      tickfont = list(size = 35),
                      range = c(0, 150),
                      dtick = 30),
         legend = list(x = 0.73, y = 1.1, orientation = "h", font = list(size = 40))) %>% 
  add_lines(x = time2, y = Izt2, type = "scatter", mode = "lines", name = "I(z<sub>avg</sub>,t)")

p1


#**ANOMALY*
p2 <- plot_ly(
  x = time2, 
  y = anomaly, 
  type = "scatter", 
  mode = "lines",
  line = list(color = "black")  # <- sets the line color
) %>% 
  layout(
    xaxis = list(
      title = "July 2023 [UTC+1]",
      titlefont = list(size = 30),  # font size for axis title
      tickfont = list(size = 30),   # font size for tick labels
      tickformat = "%d"             # optional: show day number only
    ),
    yaxis = list(
      title = "I(z<sub>i</sub>,t) - I(z<sub>avg</sub>,t) [W/m<sup>2</sup>]",
      titlefont = list(size = 30),
      tickfont = list(size = 30),
      range = c(-40, 70),
      dtick = 10)
    )


p2

library(htmlwidgets)
library(webshot)

htmlwidgets::saveWidget(p, "p.html")
webshot::webshot("p.html", "contour_ITW1_23.pdf", vwidth = 1400, vheight = 500)

htmlwidgets::saveWidget(p1, "p1.html")
webshot::webshot("p1.html", "sin_ITW1_23.pdf", vwidth = 1400, vheight = 500)

htmlwidgets::saveWidget(p2, "p2.html")
webshot::webshot("p2.html", "dif_ITW1_23.pdf", vwidth = 1400, vheight = 700)


#**FIXED SUBPLOT FOR PAPER*

library(plotly)
library(dplyr)

# ============================================================
# COMMON X-AXIS SETTINGS
# ============================================================

xmin <- as.POSIXct("2023-07-07 00:00:00", tz = "Etc/GMT-1")
xmax <- as.POSIXct("2023-07-14 00:00:00", tz = "Etc/GMT-1")

# Vertical ticks/grid lines at the BEGINNING/END of each day
day_boundaries <- seq(
  xmin,
  xmax,
  by = "1 day"
)

# Day labels positioned in the MIDDLE of each day
day_centres <- seq(
  as.POSIXct("2023-07-07 12:00:00", tz = "Etc/GMT-1"),
  as.POSIXct("2023-07-13 12:00:00", tz = "Etc/GMT-1"),
  by = "1 day"
)

day_labels <- sprintf("%02d", 7:13)


# ============================================================
# PANEL A — CONTOUR
# ============================================================

p <- plot_ly(
  x = time2,
  y = -depth[1:70],
  z = Izt[1:70, ],
  type = "contour",
  
  contours = list(
    start = 0,
    end = 300,
    size = 50
  ),
  
  colorbar = list(
    title = "I(z,t) [W/m<sup>2</sup>]",
    titlefont = list(size = 30),
    tickfont = list(size = 28)
  ),
  # Removes the contour colorbar
  showscale = FALSE
) %>%
  
  add_trace(
    x = time2,
    y = -isotherm_depth2,
    type = "scatter",
    mode = "lines",
    
    line = list(
      color = "orange",
      width = 4
    ),
    
    showlegend = FALSE
  ) %>%
  
  layout(
    yaxis = list(
      title = "z [m]",
      titlefont = list(size = 30),
      tickfont = list(size = 28)
    ),
    
    showlegend = FALSE
  )


# ============================================================
# PANEL B — I(z_i,t) vs I(z_avg,t)
# ============================================================

p1 <- plot_ly(
  x = time2,
  y = Izt1,
  type = "scatter",
  mode = "lines",
  
  name = "I(z<sub>i</sub>,t)",
  
  line = list(
    color = "#1f77b4",
    width = 3
  )
) %>%
  
  add_lines(
    x = time2,
    y = Izt2,
    
    name = "I(z<sub>avg</sub>,t)",
    
    line = list(
      color = "#ff7f0e",
      width = 3
    )
  ) %>%
  
  layout(
    yaxis = list(
      title = "I(z,t) [W/m<sup>2</sup>]",
      titlefont = list(size = 30),
      tickfont = list(size = 28),
      range = c(0, 150),
      dtick = 30
    )
  )



# ============================================================
# PANEL C — ANOMALY
# ============================================================

p2 <- plot_ly(
  x = time2,
  y = anomaly,
  type = "scatter",
  mode = "lines",
  
  line = list(
    color = "black",
    width = 3
  ),
  
  showlegend = FALSE
) %>%
  
  layout(
    yaxis = list(
      title = "I(z<sub>i</sub>,t) - I(z<sub>avg</sub>,t) [W/m<sup>2</sup>]",
      titlefont = list(size = 30),
      tickfont = list(size = 28),
      range = c(-40, 70),
      dtick = 10
    )
  )


# ============================================================
# COMBINE PANELS
# ============================================================

fig <- subplot(
  p,
  p1,
  p2,
  
  nrows = 3,
  
  # each subplot retains its own x-axis
  shareX = FALSE,
  
  heights = c(0.36, 0.32, 0.32),
  
  # space between panels
  margin = 0.07,
  
  titleX = TRUE,
  titleY = TRUE
)


# ============================================================
# CREATE DAY-LABEL ANNOTATIONS
# ============================================================

annotations <- list()


# ------------------------------------------------------------
# PANEL A labels
# ------------------------------------------------------------

for (i in seq_along(day_centres)) {
  
  annotations[[length(annotations) + 1]] <- list(
    
    x = day_centres[i],
    y = -0.08,
    
    xref = "x",
    yref = "y domain",
    
    text = day_labels[i],
    
    showarrow = FALSE,
    
    font = list(
      size = 28
    ),
    
    xanchor = "center",
    yanchor = "top"
  )
}


# ------------------------------------------------------------
# PANEL B labels
# ------------------------------------------------------------

for (i in seq_along(day_centres)) {
  
  annotations[[length(annotations) + 1]] <- list(
    
    x = day_centres[i],
    y = -0.08,
    
    xref = "x2",
    yref = "y2 domain",
    
    text = day_labels[i],
    
    showarrow = FALSE,
    
    font = list(
      size = 28
    ),
    
    xanchor = "center",
    yanchor = "top"
  )
}


# ------------------------------------------------------------
# PANEL C labels
# ------------------------------------------------------------

for (i in seq_along(day_centres)) {
  
  annotations[[length(annotations) + 1]] <- list(
    
    x = day_centres[i],
    y = -0.08,
    
    xref = "x3",
    yref = "y3 domain",
    
    text = day_labels[i],
    
    showarrow = FALSE,
    
    font = list(
      size = 28
    ),
    
    xanchor = "center",
    yanchor = "top"
  )
}


# ============================================================
# FINAL LAYOUT
# ============================================================

fig <- fig %>%
  layout(
    
    # --------------------------------------------------------
    # PANEL A x-axis
    # --------------------------------------------------------
    
    xaxis = list(
      
      range = c(xmin, xmax),
      
      tickmode = "array",
      tickvals = day_boundaries,
      
      # do NOT show Plotly's automatic labels
      # because our labels are centred manually
      showticklabels = FALSE,
      
      # tick marks at midnight/day boundaries
      ticks = "outside",
      ticklen = 8,
      
      # vertical grid lines at midnight/day boundaries
      showgrid = TRUE,
      
      title = list(
        text = "July 2023 [UTC+1]",
        font = list(size = 30)
      )
    ),
    
    
    # --------------------------------------------------------
    # PANEL B x-axis
    # --------------------------------------------------------
    
    xaxis2 = list(
      
      range = c(xmin, xmax),
      
      tickmode = "array",
      tickvals = day_boundaries,
      
      showticklabels = FALSE,
      
      ticks = "outside",
      ticklen = 8,
      
      showgrid = TRUE,
      
      title = list(
        text = "July 2023 [UTC+1]",
        font = list(size = 30)
      )
    ),
    
    
    # --------------------------------------------------------
    # PANEL C x-axis
    # --------------------------------------------------------
    
    xaxis3 = list(
      
      range = c(xmin, xmax),
      
      tickmode = "array",
      tickvals = day_boundaries,
      
      showticklabels = FALSE,
      
      ticks = "outside",
      ticklen = 8,
      
      showgrid = TRUE,
      
      title = list(
        text = "July 2023 [UTC+1]",
        font = list(size = 30)
      )
    ),
    
    
    # --------------------------------------------------------
    # DAY LABELS 07–13
    # centred between the vertical day-boundary lines
    # --------------------------------------------------------
    
    annotations = annotations,
    
    
    # --------------------------------------------------------
    # LEGEND — positioned inside panel B
    # --------------------------------------------------------
    
    legend = list(
      
      x = 0.70,
      y = 0.62,
      
      xanchor = "left",
      yanchor = "top",
      
      orientation = "h",
      
      font = list(
        size = 28
      ),
      
      bgcolor = "rgba(255,255,255,0)"
    ),
    
    
    # --------------------------------------------------------
    # OUTER FIGURE MARGINS
    # --------------------------------------------------------
    
    margin = list(
      l = 130,
      r = 120,
      b = 100,
      t = 50
    )
  )


# ============================================================
# SHOW FINAL FIGURE
# ============================================================

fig


install.packages("webshot2")
library(htmlwidgets)
library(webshot2)

# Save widget
htmlwidgets::saveWidget(
  fig,
  "p.html",
  selfcontained = TRUE
)

# Export to PDF
webshot2::webshot(
  url = "p.html",
  file = "light_model_subplot_Matek_Rad_0209.pdf",
  vwidth = 1200,
  vheight = 1100,
  delay = 1
)

