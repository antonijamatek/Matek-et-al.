source("C:/Users/Antonija/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza 2023 - Experiment III/Light 23/PAR_23/packages.R")

Sys.setlocale("LC_TIME", "C")


#time stamps are UTC+1!

#time-indexing data
par10ts <- zoo(par10$`PAR [μmol/(m2s)]`, order.by = par10$TimeStamp)
par30ts <- zoo(par30$`PAR [μmol/(m2s)]`, order.by = par30$TimeStamp)

#low-pass filtering to 1 hour interval using a moving average 
window_size <- 12 
#par10
par10ts_12 <- rollapply(par10ts, width = window_size, FUN = mean, 
                        align = "center", fill = NA)
#converting timestamp into one hour interval
timestamp <- as.POSIXct(index(par10ts_12))
par10ts_12 <- aggregate(par10ts_12, as.POSIXct(cut(timestamp, "hour")), mean)

#par30
par30ts_12 <- rollapply(par30ts, width = window_size, FUN = mean, 
                         align = "center", fill = NA)
#converting timestamp into one hour interval
timestamp <- as.POSIXct(index(par30ts_12))
par30ts_12 <- aggregate(par30ts_12, as.POSIXct(cut(timestamp, "hour")), mean)

save(par10ts_12, par30ts_12, file = "par_for_paper_2023.Rdata")

#low-pass filtering to 3 hour interval using a moving average 
window_size <- 36

#par10
par10ts_36 <- rollapply(par10ts, width = window_size, FUN = mean, 
                        align = "center", fill = NA)

#converting timestamp into three hour interval
timestamp <- as.POSIXct(index(par10ts_36))
par10ts_36 <- aggregate(par10ts_36, as.POSIXct(cut(timestamp, "3 hours")), mean)

#par30
par30ts_36 <- rollapply(par30ts, width = window_size, FUN = mean, 
                        align = "center", fill = NA)
#converting timestamp into three hour interval
timestamp <- as.POSIXct(index(par30ts_36))
par30ts_36 <- aggregate(par30ts_36, as.POSIXct(cut(timestamp, "3 hours")), mean)

#checking length of the vectors
length(par10ts)
length(par30ts)
length(par10ts_12)
length(par30ts_12)
length(par10ts_36)
length(par30ts_36)

#checking NA in the time series
#is.na(par10ts)
#is.na(par30ts)
#is.na(par10ts_12)
#is.na(par30ts_12)

#omitting NA in the time series, and checking length again
#par10ts_12 <- na.omit(par10ts_12)
#par30ts_12 <- na.omit(par30ts_12)

x <- tidy(par10ts)
time <- x$index

save(par10ts, par10ts_12, par30ts, par30ts_12, file = "par for K estimate.RData")
save(timestamp, file = "time for interpolation.RData")
save(par10, file = "par for light model.RData")
