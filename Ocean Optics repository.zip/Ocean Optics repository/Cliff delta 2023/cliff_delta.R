source("C:/Users/Tihomir/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza/Data_coherence_I_II_III/Correlation/packages.R")


# Packages
library(dplyr)
library(tidyr)
library(ggplot2)
library(effsize)
library(ggtext)


# Read data

npp22 <- readxl::read_xlsx("C:/Users/Antonija/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza/Data_coherence_I_II_III/Cliff delta and profiles/npp_2022.xlsx")
npp23 <- readxl::read_xlsx("C:/Users/Antonija/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza/Data_coherence_I_II_III/Cliff delta and profiles/npp_2023.xlsx")


# 1) Variables to test 
vars <- c("Temperature (°C)", "PBT_z", "PT_z", "Chla",
          "Oxygen (mgL-1)", "NO3", "PO4", "SiO4")

vars22 <- vars[vars %in% names(npp22)]
vars23 <- vars[vars %in% names(npp23)]

layers <- c("SURFACE", "THERMOCLINE", "DEEP LAYER")

# 2) Function: Cliff's delta (ITW Yes vs No) within a layer
# Interpretation here: positive δ means values in ITW(Yes) tend to be higher than No
compare_itw <- function(df, var_name, layer_name) {
  
  x_yes <- df %>%
    filter(ITWs == "Yes", Layer == layer_name) %>%
    pull(.data[[var_name]]) %>%
    as.numeric()
  
  x_no <- df %>%
    filter(ITWs == "No", Layer == layer_name) %>%
    pull(.data[[var_name]]) %>%
    as.numeric()
  
  x_yes <- x_yes[is.finite(x_yes)]
  x_no  <- x_no[is.finite(x_no)]
  
  # handle tiny groups safely
  if (length(x_yes) < 1 || length(x_no) < 1) {
    return(tibble(
      variable = var_name, layer = layer_name,
      n_itw = length(x_yes), n_noitw = length(x_no),
      cliff_delta = NA_real_
    ))
  }
  
  cd <- effsize::cliff.delta(x_yes, x_no)  # Yes vs No
  
  tibble(
    variable = var_name,
    layer = layer_name,
    n_itw = length(x_yes),
    n_noitw = length(x_no),
    median_itw = median(x_yes, na.rm = TRUE),
    median_noitw = median(x_no, na.rm = TRUE),
    cliff_delta = unname(cd$estimate),
    cliff_low = cd$conf.int[1],
    cliff_high = cd$conf.int[2]
  )
}

# 3) Apply across all variables & layers 

cliff_22 <- expand.grid(var = vars22, 
                             layer = layers, 
                             stringsAsFactors = FALSE) %>%
  rowwise() %>%
  do(compare_itw(npp22, .$var, .$layer)) %>%
  ungroup() %>%
  mutate(
    layer = factor(layer, levels = layers),
    variable = factor(variable, levels = vars)
  )

cliff_22

cliff_23 <- expand.grid(var = vars23, 
                        layer = layers, 
                        stringsAsFactors = FALSE) %>%
  rowwise() %>%
  do(compare_itw(npp23, .$var, .$layer)) %>%
  ungroup() %>%
  mutate(
    layer = factor(layer, levels = layers),
    variable = factor(variable, levels = vars)
  )

cliff_23


# 4) Plot: heatmap of Cliff's delta

variable_labels <- c(
  "Temperature (°C)" = "bold('Temperature')",
  "PBT_z"            = "bold(P[T]^B~(z))",
  "PT_z"             = "bold(P[T]~(z))",
  "Chla"             = "bold(Chl~bolditalic(a))",
  "Oxygen (mgL-1)"   = "bold(O[2])",
  "NO3"              = "bold(NO[3])",
  "PO4"              = "bold(PO[4])",
  "SiO4"             = "bold(SiO[4])"
)


# Filter only Surface and Thermocline
cliff_22_plot <- cliff_22 %>%
  filter(layer %in% c("SURFACE", "THERMOCLINE")) %>%
  mutate(
    layer = factor(layer, levels = c("SURFACE", "THERMOCLINE"))
  )


cliff_23_plot <- cliff_23 %>%
  filter(layer %in% c("SURFACE", "THERMOCLINE")) %>%
  mutate(
    layer = factor(layer, levels = c("SURFACE", "THERMOCLINE"))
  )

# Plot
p22 <- ggplot(cliff_22_plot,
                      aes(x = variable, y = layer, fill = cliff_delta)) +
  geom_tile(color = "white", linewidth = 0.4) +
  scale_fill_gradient2(
    low = "#2166ac",
    mid = "white",
    high = "#b2182b",
    midpoint = 0,
    limits = c(-1, 1),
    name = "Cliff's δ"
  ) +
  scale_x_discrete(
    labels = function(x) parse(text = variable_labels[x])
  )+
  labs(
    x = NULL,
    y = NULL,
    title = "June 2022"
  ) +
  theme_bw() +
  theme(
    axis.text.x = element_text(angle = 0,
                               vjust = 1,
                               hjust = 0.5,
                               face = "bold",
                               size = 20
    ),
    axis.text.y = element_text( angle = 90,
                                vjust = 1,
                                hjust = 0.6,
                                face = "bold",
                                size = 20
    ),
    legend.title = element_text(face = "bold",
                                size = 20),
    legend.text = element_text(face = "bold",
                               size = 20),
    panel.grid = element_blank(),
    plot.title = element_text(
      size = 20,
      face = "bold"
    )
  )


p22


p23 <- ggplot(cliff_23_plot,
              aes(x = variable, y = layer, fill = cliff_delta)) +
  geom_tile(color = "white", linewidth = 0.4) +
  scale_fill_gradient2(
    low = "#2166ac",
    mid = "white",
    high = "#b2182b",
    midpoint = 0,
    limits = c(-1, 1),
    name = "Cliff's δ"
  ) +
  scale_x_discrete(
    labels = function(x) parse(text = variable_labels[x])
  )+
  labs(
    x = NULL,
    y = NULL,
    title = "July 2023"
  ) +
  theme_bw() +
  theme(
    axis.text.x = element_text(angle = 0,
                               vjust = 1,
                               hjust = 0.5,
                               face = "bold",
                               size = 20
    ),
    axis.text.y = element_text( angle = 90,
                                vjust = 1,
                                hjust = 0.6,
                                face = "bold",
                                size = 20
    ),
    legend.title = element_text(face = "bold",
                                size = 20),
    legend.text = element_text(face = "bold",
                               size = 20),
    panel.grid = element_blank(),
    plot.title = element_text(
      size = 20,
      face = "bold"
    )
  )


p23

ggsave(
  filename = "cliff_delta_2023.pdf",
  plot = p23,
  width = 14,
  height = 6,
  dpi = 300,
  units = "in"
)

ggsave(
  filename = "cliff_delta_2023.tif",
  plot = p23,
  width = 14,
  height = 6,
  dpi = 300,
  units = "in"
)


#**Final plot for paper*

library(cowplot)

# remove legend from p23
p23 <- p23 +
  theme(legend.position = "none")+
  labs(tag = "B") +
  theme(
    plot.tag = element_text(face = "bold", size = 20)
  )

# extract legend from p22
legend <- cowplot::get_legend(
  p22 + theme(
    legend.position = "right",
    legend.box.margin = margin(0, 0, 0, 0)
  )
)

# remove legend from p22
p22 <- p22 +
  theme(legend.position = "none")+ labs(tag = "A") +
  theme(
    plot.tag = element_text(face = "bold", size = 20)
  )

# combine two plots
p <- cowplot::plot_grid(
  p22,
  p23,
  ncol = 1,
  labels = NULL,
  align = "hv"
)

# position the legend
legend_top <- plot_grid(
  legend,
  NULL,
  ncol = 1,
  rel_heights = c(0.25, 0.65)
)

#plot the final image

p_combined <- plot_grid(
  p,
  legend_top,
  ncol = 2,
  rel_widths = c(1, 0.12)
)


p_combined


ggsave(
  filename = "cliff_delta_2022_2023.pdf",
  plot = p_combined,
  width = 16,
  height = 12,
  dpi = 300,
  units = "in"
)

ggsave(
  filename = "cliff_delta_2022_2023.tif",
  plot = p_combined,
  width = 16,
  height = 12,
  dpi = 300,
  units = "in"
)

 aggregate(
      Chla ~ ITWs + Layer,
      data = npp22,
       median
   )
 
 aggregate(
   Chla ~ ITWs + Layer,
   data = npp23,
   median
 )
 
 
 npp22 %>%
   filter(Layer == "THERMOCLINE") %>%
   select(
     Station,
     z_m,
     ITWs,
     PT_z,
     PBT_z,
     Chla
   ) %>%
   arrange(ITWs, z_m)
 
 
 npp23 %>%
   filter(Layer == "THERMOCLINE") %>%
   select(
     Experiment,
     z_m,
     ITWs,
     PT_z,
     PBT_z,
     Chla
   ) %>%
   arrange(ITWs, z_m)

  
 