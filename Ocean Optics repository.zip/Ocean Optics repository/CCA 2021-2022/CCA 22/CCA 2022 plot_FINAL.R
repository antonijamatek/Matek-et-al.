#1. Loading packages
library("vegan")
library("dplyr")
library("readr")
library("ggvegan")
library("ggrepel")
library("ggplot2")

#2. Code for plotting using plot() function 
plot(struga.cca, type = "n", scaling = scl, display = c("species", "sites"))
points(struga.cca, scaling = scl, display = "species", cex = 1.0, col = "red")
points(struga.cca, scaling = scl, display = "sites", cex = 1.0, col = "black")
ordipointlabel(struga.cca, display = "species", scaling = scl, add = TRUE)
text(struga.cca, display = "bp", col = "blue", scaling=scl)

#defining graphics for ggplots
vignette("ggplot2-specs")#graphics info
?pch #graphics info
shape_names <- c("circle", paste("circle", c("open", "filled", "cross", "plus", "small")), "bullet", #definig shape names
                 "square", paste("square", c("open", "filled", "cross", "plus", "triangle")),
                 "diamond", paste("diamond", c("open", "filled", "plus")),
                 "triangle", paste("triangle", c("open", "filled", "square")),
                 paste("triangle down", c("open", "filled")),
                 "plus", "cross", "asterisk")
cols <- c("blue", "black", "red") #defining colors for ggplot points
shapes <- c("cross", "diamond", "triangle") #defining shapes for ggplot points

#ONLY PHYTOPLANKTON 
#3. Creating a dataset that will be plotted with ggvegan package
#The convention with ggplot2 is to `fortify()` the object we wish to plot, 
#which basically means turn the object into a format that is suitable for plotting with `ggplot()`

#fortify the ordination
ford <- fortify(struga.cca, axes = 1:2, scaling = "symmetric")
sites <- fortify(struga.cca, axes = 1:2, scaling = "symmetric", display = "wa")
species <- fortify(struga.cca, axes = 1:2, scaling = "symmetric", display = "species")
bp <- fortify (struga.cca, axes = 1:2, scaling = "symmetric", display = "bp")
#create a tibble 
head(ford, 10)
tail(ford,10)
#add factor for water layer column
sites <- sites %>%
  bind_cols(strugaf.)
colnames(sites)[8] <- "Waterlayer"
#D renaiming species labels
species$label <- c("Diatoms (micro)", "Dino (micro)", "Dino (nano)", "Cocco (micro)", "Cocco (nano)",
                            "Cryptophyta", "Chlorophyceae", "Micro", "Nano")

#4. Code for plot in ggvegan
#plotting struga.cca model 
ggplot(ford, aes(x = CCA1, y = CCA2)) +
  geom_hline(yintercept = 0, colour = "gray", alpha = 0.5) +
  geom_vline(xintercept = 0, colour = "gray", alpha = 0.5) +   
  geom_point(data = sites, 
             mapping = aes(colour = Waterlayer), size=4) +
  scale_color_manual(values = cols) +
  geom_label(data = species, label=species$label, label.size = 0.5, cex=7)+
  geom_label(data = bp, label=bp$label, label.size = 0.5, cex=7)+
  geom_segment(mapping = aes(x=0, y=0, xend=CCA1*10, yend=CCA2*10),
               arrow=arrow(length = unit(0.8, "cm")), 
               data=filter(bp),color="black") +
  theme_classic()+
  theme(axis.text.y = element_text(size = rel(3), angle = 00),
        axis.text.x = element_text(size = rel(3), angle = 00),
        axis.title.y = element_text(size = rel(1.7), angle = 90),
        axis.title.x = element_text(size = rel(1.7), angle = 00),
        legend.title = element_blank(),
        legend.key.size = unit(1.3, "cm"),
        legend.text = element_text(size = unit(15, "cm")),
        legend.position = "right",
        axis.text = element_text(size = 6))+
  labs(x = "CCA1 (47.75 %, p=0.011)", y = "CCA2 (20.09 %, p=0.587)") + 
  annotate("text", x = Inf, y = Inf, 
           label = "Total of 11.70% (p=0.002) variability is explained by constrained axes", 
           hjust = 1, vjust = 1, cex=7)  

#geom_text_repel(data = filter(species), mapping = aes(label = label), min.segment.length = 4) +
#geom_text_repel(data = filter(bp), mapping = aes(label = label))+
#geom_text_repel(data = filter(species), mapping = aes(label = label), min.segment.length = 4) +
#geom_text_repel(data = filter(bp), mapping = aes(label = label))+
#Saving ggplot as image
#ggsave(filename = "my_ggplot.png", plot = CCA_S1,width = 10, height = 7,dpi = 700)

#ONLY PICOPHYTOPLANKTON 
#3. Creating a dataset that will be plotted with ggvegan package
#fortify the ordination
ford2 <- fortify(struga.cca2, axes = 1:2, scaling = "symmetric")
sites2 <- fortify(struga.cca2, axes = 1:2, scaling = "symmetric", display = "wa")
species2 <- fortify(struga.cca2, axes = 1:2, scaling = "symmetric", display = "species")
bp2 <- fortify (struga.cca2, axes = 1:2, scaling = "symmetric", display = "bp")
#create a tibble 
head(ford2, 10)
tail(ford2,10)
#add factor for water layer column
sites2 <- sites2 %>%
  bind_cols(strugaf)
colnames(sites2)[8] <- "Waterlayer"
colnames(sites2)[9] <- "ITW"

#4. Code for plot in ggvegan
#plotting struga.cca2 model 
ggplot(ford2, aes(x = CCA1, y = CCA2)) +
  geom_hline(yintercept = 0, colour = "gray", alpha = 0.5) +
  geom_vline(xintercept = 0, colour = "gray", alpha = 0.5) +   
  geom_point(data = sites2, 
             mapping = aes(colour = Waterlayer), size=4) +
  scale_color_manual(values = cols) +
  geom_label(data = species2, label=species2$label, label.size = 0.5, cex=7)+
  geom_label(data = bp2, label=bp2$label, label.size = 0.5, cex=7)+
  geom_segment(mapping = aes(x=0, y=0, xend=CCA1*10, yend=CCA2*10),
               arrow=arrow(length = unit(0.8, "cm")), 
               data=filter(bp2),color="black") +
  theme_classic()+
  theme(axis.text.y = element_text(size = rel(3), angle = 00),
        axis.text.x = element_text(size = rel(3), angle = 00),
        axis.title.y = element_text(size = rel(1.7), angle = 90),
        axis.title.x = element_text(size = rel(1.7), angle = 00),
        legend.title = element_blank(),
        legend.key.size = unit(1.3, "cm"),
        legend.text = element_text(size = unit(15, "cm")),
        legend.position = "right",
        axis.text = element_text(size = 6))+
  labs(x = "CCA1 (86.41 %, p=0.001)", y = "CCA2 (2.27 %, p=0.001)") + 
  annotate("text", x = Inf, y = Inf, 
           label = "Total of 88.92% (p=0.001) variability is explained by constrained axes", 
           hjust = 1, vjust = 1, cex=7)  

#PICOPHYTOPLANKTON VS NUTRIENTS
#3. Creating a dataset that will be plotted with ggvegan package
#fortify the ordination
ford4 <- fortify(struga.cca4, axes = 1:2, scaling = "symmetric")
sites4 <- fortify(struga.cca4, axes = 1:2, scaling = "symmetric", display = "wa")
species4 <- fortify(struga.cca4, axes = 1:2, scaling = "symmetric", display = "species")
bp4 <- fortify (struga.cca4, axes = 1:2, scaling = "symmetric", display = "bp")
#create a tibble 
head(ford4, 10)
tail(ford4,10)
#add factor for water layer column
sites4 <- sites4 %>%
  bind_cols(strugaf)
colnames(sites4)[8] <- "Waterlayer"

#4. Code for plot in ggvegan
#plotting struga.cca4 model 
ggplot(ford4, aes(x = CCA1, y = CCA2)) +
  geom_hline(yintercept = 0, colour = "gray", alpha = 0.5) +
  geom_vline(xintercept = 0, colour = "gray", alpha = 0.5) +   
  geom_point(data = sites4, 
             mapping = aes(colour = Waterlayer), size=4) +
  scale_color_manual(values = cols) +
  geom_label(data = species4, label=species4$label, label.size = 0.5, cex=7)+
  geom_label(data = bp4, label=bp4$label, label.size = 0.5, cex=7)+
  geom_segment(mapping = aes(x=0, y=0, xend=CCA1*10, yend=CCA2*10),
               arrow=arrow(length = unit(0.8, "cm")), 
               data=filter(bp4),color="black") +
  theme_classic()+
  theme(axis.text.y = element_text(size = rel(3), angle = 00),
        axis.text.x = element_text(size = rel(3), angle = 00),
        axis.title.y = element_text(size = rel(1.7), angle = 90),
        axis.title.x = element_text(size = rel(1.7), angle = 00),
        legend.title = element_blank(),
        legend.key.size = unit(1.3, "cm"),
        legend.text = element_text(size = unit(15, "cm")),
        legend.position = "right",
        axis.text = element_text(size = 6))+
  labs(x = "CCA1 (50.12 %, p=0.001)", y = "CCA2 (0.08 %, p=0.417)") + 
  annotate("text", x = Inf, y = Inf, 
           label = "Total of 51.09% (p=0.001) variability is explained by constrained axes", 
           hjust = 1, vjust = 1, cex=7)  

#PLOTTING WITH ITW AS A FACTOR INSTEAD OF WATER LAYER
itw <- readxl::read_excel("itw.xlsx")
strugaf <- strugaf %>%
           bind_cols(itw)

strugaf. <- strugaf. %>%
  bind_cols(itw)

#plotting struga.cca2 model 
ggplot(ford2, aes(x = CCA1, y = CCA2)) +
  geom_hline(yintercept = 0, colour = "gray", alpha = 0.5) +
  geom_vline(xintercept = 0, colour = "gray", alpha = 0.5) +   
  geom_point(data = sites2, 
             mapping = aes(colour = ITW), size=4) +
  scale_color_manual(values = cols) +
  geom_label(data = species2, label=species2$label, label.size = 0.5, cex=7)+
  geom_label(data = bp2, label=bp2$label, label.size = 0.5, cex=7)+
  geom_segment(mapping = aes(x=0, y=0, xend=CCA1*10, yend=CCA2*10),
               arrow=arrow(length = unit(0.8, "cm")), 
               data=filter(bp2),color="black") +
  theme_classic()+
  theme(axis.text.y = element_text(size = rel(3), angle = 00),
        axis.text.x = element_text(size = rel(3), angle = 00),
        axis.title.y = element_text(size = rel(1.7), angle = 90),
        axis.title.x = element_text(size = rel(1.7), angle = 00),
        legend.title = element_blank(),
        legend.key.size = unit(1.3, "cm"),
        legend.text = element_text(size = unit(15, "cm")),
        legend.position = "right",
        axis.text = element_text(size = 6))+
  labs(x = "CCA1 (86.41 %, p=0.001)", y = "CCA2 (2.27 %, p=0.001)") + 
  annotate("text", x = Inf, y = Inf, 
           label = "Total of 88.92% (p=0.001) variability is explained by constrained axes", 
           hjust = 1, vjust = 1, cex=7)  

#plotting struga.cca4 model 
ggplot(ford4, aes(x = CCA1, y = CCA2)) +
  geom_hline(yintercept = 0, colour = "gray", alpha = 0.5) +
  geom_vline(xintercept = 0, colour = "gray", alpha = 0.5) +   
  geom_point(data = sites4, 
             mapping = aes(colour = ITW), size=4) +
  scale_color_manual(values = cols) +
  geom_label(data = species4, label=species4$label, label.size = 0.5, cex=7)+
  geom_label(data = bp4, label=bp4$label, label.size = 0.5, cex=7)+
  geom_segment(mapping = aes(x=0, y=0, xend=CCA1*10, yend=CCA2*10),
               arrow=arrow(length = unit(0.8, "cm")), 
               data=filter(bp4),color="black") +
  theme_classic()+
  theme(axis.text.y = element_text(size = rel(3), angle = 00),
        axis.text.x = element_text(size = rel(3), angle = 00),
        axis.title.y = element_text(size = rel(1.7), angle = 90),
        axis.title.x = element_text(size = rel(1.7), angle = 00),
        legend.title = element_blank(),
        legend.key.size = unit(1.3, "cm"),
        legend.text = element_text(size = unit(15, "cm")),
        legend.position = "right",
        axis.text = element_text(size = 6))+
  labs(x = "CCA1 (50.12 %, p=0.001)", y = "CCA2 (0.08 %, p=0.417)") + 
  annotate("text", x = Inf, y = Inf, 
           label = "Total of 51.09% (p=0.001) variability is explained by constrained axes", 
           hjust = 1, vjust = 1, cex=7)