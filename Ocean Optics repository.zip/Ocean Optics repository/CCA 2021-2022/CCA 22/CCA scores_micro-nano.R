#INSTALL PACKAGES
pkgs <- c("vegan", "tidyverse", "cocorresp", "permute", "here", "tibble",
          "readxl", "janitor", "stringr", "ggrepel") 
install.packages(pkgs, Ncpus = cores - 1)
#enable repository from gavinsimpson
options(repos = c(
  gavinsimpson = 'https://gavinsimpson.r-universe.dev',
  CRAN = 'https://cloud.r-project.org'))
#download and install ggvegan in R
install.packages("ggvegan")

#LOAD PACKAGES
library("vegan")
library("dplyr")
library("readr")
library("ggvegan")
library("ggrepel")

#IMPORT DATA
strugagroups <- readxl::read_excel("strugagroups.xlsx")
strugaenv <- readxl::read_excel("strugaenv.xlsx")
strugaf <- readxl::read_excel("strugafactors.xlsx") #dataset needed later for plotting 

#EDIT DATA
#environment
strugaenv$NO2 <- as.double(strugaenv$NO2)
strugaenv$NO3 <- as.double(strugaenv$NO3)
strugaenv$PO4 <- as.double(strugaenv$PO4)
strugaenv$SiO4 <- as.double(strugaenv$SiO4)
strugaenv$`Chl a` <- as.double(strugaenv$`Chl a`)
strugaenv$Temperature <- sub(",",".",strugaenv$Temperature)
strugaenv$Temperature <- as.double(strugaenv$Temperature)
names(strugaenv) <- c("NO2", "NO3", "PO4", "SiO4","Temperature", "Chla", "Waterlayer", "ITWs")
#replacing NA with 0, vice versa 
strugaenv <- strugaenv %>%
  mutate(across(NO2:Chla, .fns = tidyr::replace_na, replace = 0))
#plankton groups
strugagroups$Picoeukaryotes <- as.double(strugagroups$Picoeukaryotes)
strugagroups$Synechococcus <- as.double(strugagroups$Synechococcus)
strugagroups$Prochlorococcus <- as.double(strugagroups$Prochlorococcus)
strugagroups$`Heterotrophic bacteria`<- as.double(strugagroups$`Heterotrophic bacteria`)

#ANALYSIS
#1. filter the strugragroups for all groups beside picophytoplankton
strugagroups. <- strugagroups %>%
  select(-Picoeukaryotes, -Synechococcus, -Prochlorococcus, -`Heterotrophic bacteria`)
colnames(strugagroups.)
#calculate row sums
row_sums <- rowSums(strugagroups.)
#keep rows where the sum is greater than zero
non_zero_rows <- row_sums > 0
#filter  to keep non-zero rows
strugagroups. <- strugagroups.[non_zero_rows, ]
#filter the corresponding rows in the environmental data
strugaenv. <- strugaenv[non_zero_rows, ]
#filter the corresponding rows in strugaf (dataset needed later f)
strugaf. <- strugaf[non_zero_rows, ]

#2. normalizing data
#log transforming environment data
senvlog. <- strugaenv. [-7] %>%
  mutate(across(NO2:Chla, .fns = log1p))
#standardize environmental data
senvlog. <- scale(senvlog.)
senvlog. <- tibble::as_tibble(senvlog.)
dim(senvlog.)
#log transforming group data
sgroupslog. <- log(strugagroups. +1)
sgroupslog. <- tibble::as_tibble(sgroupslog.)
dim(sgroupslog.)

#3.Canonical correspondence analysis (CCA) 
struga.cca <- cca(sgroupslog. ~ NO2 + NO3 + PO4 + SiO4 + Temperature + Chla, data=senvlog.)
struga.cca
summary(struga.cca)

#4. Testing statistical significance 
#for struga.cca model 
set.seed(1)
anova(struga.cca, permutations = 999) #The model is significant
#for constrained axis 
set.seed(42)
anova(struga.cca, permutations = 999, by = "axis", parallel = 4) #only CCA1 axis is significant

#PLOT SCORES
#Plot scores of both CCA analysis
#Weighted average scores include the variation in the species composition
#The LC scores are weighted & scaled versions of the constraints (predictors)
#The WA scores are weighted averages of the species (responses) that are as close to the LC scores as possible
plot(struga.cca, display = c("species")) #species scores
plot(struga.cca, display = c("bp"))#biplot scores for constraining variables 
plot(struga.cca, display = c("wa")) #weighted averages of species scores (site constraints)
plot(struga.cca, display = c("lc")) #linear combinations of constraining variables (site constraints)
plot(struga.cca, display = c("bp", "wa"))
dev.off()
set.seed(1)
par(mfrow=c(1,2))
plot(struga.cca, display="species", cex.lab=1.5, cex.axis=1.5)
plot(struga.cca, display = c("bp", "wa", cex=1.5), cex.lab=1.5, cex.axis=1.5)

#STATISTICS SUMMARY
#for the plot: struga.cca micro_nanophyto, CCA1: 47.75%, CCA2: 20.09% - contribution of each axis to 11.70% variability explained by environment
#ANOVA test of significance for CCA model with micro and nanophytoplankton:  p=0.002
# -=- for significance of constrained axis: CCA1 is significant - p=0.011. CCA2 is not - p=0.587
cca_summary <- summary(struga.cca)
cca_biplot <- as.data.frame(cca_summary$biplot)
cca_species <- as.data.frame(cca_summary$species)
cca_eigen <- as.data.frame(cca_summary$concont)
#save to excel
writexl::write_xlsx(cca_biplot, "CCA_micro-nano_biplot.xlsx")
writexl::write_xlsx(cca_species, "CCA_micro-nano_species.xlsx")
writexl::write_xlsx(cca_eigen, "CCA_micro-nano_eigen.xlsx")


#**CREATE A MODEL WITHOUT NO2 - FOR NPP COANALYSIS*

x <- sgroupslog.
y <- senvlog.

struga.cca_ex <- cca(x ~ NO3 + PO4 + SiO4 + Temperature + Chla, data=y)
struga.cca_ex
summary(struga.cca_ex)

#save in RData
cca22m <- struga.cca_ex
cca22p <- struga.cca2_ex

save(cca22m, cca22p, file = "cca22.RData")



#**CREATE A MODEL WITHOUT NO2, SiO4 and Chla - FOR NPP COANALYSIS*

x <- sgroupslog.
y <- senvlog.
struga.cca_ex2 <- cca(x ~ NO3 + PO4 + Temperature, data=y)
struga.cca_ex2
summary(struga.cca_ex2)

#save in RData
cca22m2 <- struga.cca_ex2
cca22p2 <- struga.cca2_ex2

save(cca22m2, cca22p2, file = "cca22_2.RData")

#**CREATE A MODEL WITH Chl a - FOR NPP COANALYSIS*

x <- sgroupslog.
y <- senvlog.
struga.cca_ex3 <- cca(x ~ Chla, data=y)
struga.cca_ex3
summary(struga.cca_ex3)

#save in RData
cca22m3 <- struga.cca_ex3
cca22p3 <- struga.cca2_ex3

save(cca22m3, cca22p3, file = "cca22_3.RData")
