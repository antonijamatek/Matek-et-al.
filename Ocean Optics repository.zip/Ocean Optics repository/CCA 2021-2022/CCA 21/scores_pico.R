#INSTALL PACKAGES
#pkgs <- c("vegan", "tidyverse", "cocorresp", "permute", "here", "tibble",
#          "readxl", "janitor", "stringr", "ggrepel") 
#install.packages(pkgs, Ncpus = cores - 1)
#enable repository from gavinsimpson
#options(repos = c(
#  gavinsimpson = 'https://gavinsimpson.r-universe.dev',
#  CRAN = 'https://cloud.r-project.org'))
#download and install ggvegan in R
#install.packages("ggvegan")

#LOAD PACKAGES
library("vegan")
library("dplyr")
library("readr")
library("ggvegan")
library("ggrepel")

#IMPORT DATA
strugagroups <- readxl::read_excel("strugagroups.xlsx")
strugaenv <- readxl::read_excel("strugaenv.xlsx")
strugaf <- readxl::read_excel("strugafactors.xlsx") #dataset needed later for plotting 

#EDIT DATA
#environment
strugaenv$NO2 <- as.double(strugaenv$NO2)
strugaenv$NO3 <- as.double(strugaenv$NO3)
strugaenv$PO4 <- as.double(strugaenv$PO4)
strugaenv$SiO4 <- as.double(strugaenv$SiO4)
strugaenv$`Chl a` <- as.double(strugaenv$`Chl a`)
strugaenv$Temperature <- sub(",",".",strugaenv$Temperature)
strugaenv$Temperature <- as.double(strugaenv$Temperature)
colnames(strugaenv) <- c("NO2", "NO3", "PO4", "SiO4","Temperature", "Chla", "Waterlayer")
#replacing NA with 0, vice versa 
strugaenv <- strugaenv %>%
  mutate(across(NO2:Chla, \(x) tidyr::replace_na(x, 0)))
#planktongroups
strugagroups$Picoeukaryotes <- as.double(strugagroups$Picoeukaryotes)
strugagroups$Synechococcus <- as.double(strugagroups$Synechococcus)
strugagroups$Prochlorococcus <- as.double(strugagroups$Prochlorococcus)
strugagroups$`Heterotrophic bacteria`<- as.double(strugagroups$`Heterotrophic bacteria`)


#ANALYSIS
#1. filter the strugragroups for picophytoplankton
strugapico <- strugagroups %>%
  select(Picoeukaryotes, Synechococcus, Prochlorococcus, `Heterotrophic bacteria`)
colnames(strugapico)

#2. normalizing data
#log transforming environment data
senvlog <- strugaenv [-7] %>%
  mutate(across(NO2:Chla, .fns = log1p))
#standardize environmental data
senvlog <- scale(senvlog)
senvlog <- tibble::as_tibble(senvlog)
dim(senvlog)
#log transforming group data
spicolog <- log(strugapico + 1)
dim(spicolog)

#3.Canonical correspondence analysis (CCA) 
struga.cca2 <- cca(spicolog ~ NO2 + NO3 + PO4 + SiO4 + Temperature + Chla, data=senvlog)
struga.cca2
summary(struga.cca2)

#4. Testing statistical significance 
#for struga.cca2 model 
set.seed(1)
anova(struga.cca2, permutations = 999) #The model is significant
#for constrained axis 
set.seed(42)
anova(struga.cca2, permutations = 999, by = "axis", parallel = 4) #only CCA1 axis is significant

#PLOT SCORES
#Plot scores of both CCA analysis
#Weighted average scores include the variation in the species composition
#The LC scores are weighted & scaled versions of the constraints (predictors)
#The WA scores are weighted averages of the species (responses) that are as close to the LC scores as possible
plot(struga.cca2, display = c("species")) #species scores
plot(struga.cca2, display = c("bp"))#biplot scores for constraining variables 
plot(struga.cca2, display = c("wa")) #weighted averages of species scores (site constraints)
plot(struga.cca2, display = c("lc")) #linear combinations of constraining variables (site constraints)
plot(struga.cca2, display = c("bp", "wa"))
dev.off()
set.seed(1)
par(mfrow=c(1,2))
plot(struga.cca2, display = c("species"), cex.lab=1.5, cex.axis=1.5)  
plot(struga.cca2, display = c("bp", "wa"), cex.lab=1.5, cex.axis=1.5)

#STATISTICS SUMMARY
#for the plot: struga.cca2 pico, CCA1:86.41%, CCA2: 2.27% - contribution of each axis to 88.92% variability explained by environment 
#ANOVA test of significance for CCA model with picophytoplankton: p=0.001
# -=- for significance of constrained axis: CCA1 and CCA2 are significant- p=0.001
cca2_summary <- summary (struga.cca2)
cca_biplot2 <- as.data.frame(cca2_summary$biplot)
cca_species2 <- as.data.frame(cca2_summary$species)
cca_eigen2 <- as.data.frame(cca2_summary$concont)
#Save the data frame to an Excel file
writexl::write_xlsx(cca_biplot2, "CCA_pico_biplot.xlsx")
writexl::write_xlsx(cca_species2, "CCA_pico_species.xlsx")
writexl::write_xlsx(cca_eigen2, "CCA_pico_eigen.xlsx")


#**CREATE A MODEL WITHOUT NO2 - FOR NPP COANALYSIS*
x <- spicolog
y <- senvlog
struga.cca2_ex <- cca(x ~ NO3 + PO4 + SiO4 + Temperature + Chla, data=y)
struga.cca2_ex
summary(struga.cca2_ex)

#**CREATE A MODEL WITHOUT NO2, SiO4 and Chla - FOR NPP COANALYSIS*

x <- spicolog
y <- senvlog
struga.cca2_ex2 <- cca(x ~ NO3 + PO4 + Temperature, data=y)
struga.cca2_ex2
summary(struga.cca2_ex2)



#**CREATE A MODEL WITH Chla - FOR NPP COANALYSIS*

x <- spicolog
y <- senvlog
struga.cca2_ex3 <- cca(x ~ Chla, data=y)
struga.cca2_ex3
summary(struga.cca2_ex3)


