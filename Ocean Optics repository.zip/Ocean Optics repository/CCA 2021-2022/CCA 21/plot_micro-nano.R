#LOAD PACKAGES
library("vegan")
library("dplyr")
library("readr")
library("ggvegan")
library("ggrepel")
library("ggplot2")

#DEFINING GRAPHICS FOR GGPLOTS
vignette("ggplot2-specs")#graphics info
?pch #graphics info
shape_names <- c("circle", paste("circle", c("open", "filled", "cross", "plus", "small")), "bullet", #definig shape names
                 "square", paste("square", c("open", "filled", "cross", "plus", "triangle")),
                 "diamond", paste("diamond", c("open", "filled", "plus")),
                 "triangle", paste("triangle", c("open", "filled", "square")),
                 paste("triangle down", c("open", "filled")),
                 "plus", "cross", "asterisk")
cols <- c("blue", "black", "red") #defining colors for ggplot points
shapes <- c("cross", "diamond", "triangle") #defining shapes for ggplot points

#PLOTTING 

#1. Fortifying the ordination that will be plotted with ggvegan package
#The convention with ggplot2 is to `fortify()` the object we wish to plot, 
#which basically means turn the object into a format that is suitable for plotting with `ggplot()`
ford <- fortify(struga.cca, axes = 1:2, scaling = "symmetric")
sites <- fortify(struga.cca, axes = 1:2, scaling = "symmetric", display = "wa")
species <- fortify(struga.cca, axes = 1:2, scaling = "symmetric", display = "species")
bp <- fortify (struga.cca, axes = 1:2, scaling = "symmetric", display = "bp")
#create a tibble 
head(ford, 10)
tail(ford,10)
#add factor for water layer column
sites <- sites %>%
  bind_cols(strugaf.)
colnames(sites)[8] <- "Waterlayer"
#renaming species labels
species$label <- c("Diatoms (micro)", "Dino (micro)", "Dino (nano)", "Cocco (micro)", "Cocco (nano)",
                   "Cryptophyta", "Chlorophyceae", "Micro", "Nano")

#2. plot struga.cca model
p <- ggplot(ford, aes(x = CCA1, y = CCA2)) +
  geom_hline(yintercept = 0, colour = "gray", alpha = 0.5) +
  geom_vline(xintercept = 0, colour = "gray", alpha = 0.5) +   
  geom_point(data = sites, 
             mapping = aes(colour = Waterlayer), size=4) +
  scale_color_manual(values = cols) +
  geom_label(data = species, label=species$label, label.size = 0.5, cex=7)+
  geom_label(data = bp, label=bp$label, label.size = 0.5, cex=7)+
  geom_segment(mapping = aes(x=0, y=0, xend=CCA1*10, yend=CCA2*10),
               arrow=arrow(length = unit(0.8, "cm")), 
               data=filter(bp),color="black") +
  theme_classic()+
  theme(axis.text.y = element_text(size = rel(3), angle = 00),
        axis.text.x = element_text(size = rel(3), angle = 00),
        axis.title.y = element_text(size = rel(1.7), angle = 90),
        axis.title.x = element_text(size = rel(1.7), angle = 00),
        legend.title = element_blank(),
        legend.key.size = unit(1.3, "cm"),
        legend.text = element_text(size = unit(15, "cm")),
        legend.position = "right",
        axis.text = element_text(size = 6))+
  labs(x = "CCA1 (10.30%, p = 0.013)", y = "CCA2 (04.23%, p = 0.405)") + 
  annotate("text", x = Inf, y = Inf, 
           label = "Total of 19.43% (p = 0.005) variability is explained by constrained axes", 
           hjust = 1, vjust = 1, cex=7)  

ggsave("CCA_micro_nano.pdf", plot = p, width = 12, height = 10, units = "in", device = "pdf")
