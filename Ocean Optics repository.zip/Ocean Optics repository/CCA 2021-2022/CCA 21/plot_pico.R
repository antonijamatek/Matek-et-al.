#LOAD PACKAGES
library("vegan")
library("dplyr")
library("readr")
library("ggvegan")
library("ggrepel")
library("ggplot2")

#DEFINING GRAPHICS FOR GGPLOTS
vignette("ggplot2-specs")#graphics info
?pch #graphics info
shape_names <- c("circle", paste("circle", c("open", "filled", "cross", "plus", "small")), "bullet", #definig shape names
                 "square", paste("square", c("open", "filled", "cross", "plus", "triangle")),
                 "diamond", paste("diamond", c("open", "filled", "plus")),
                 "triangle", paste("triangle", c("open", "filled", "square")),
                 paste("triangle down", c("open", "filled")),
                 "plus", "cross", "asterisk")
cols <- c("blue", "black", "red") #defining colors for ggplot points
shapes <- c("cross", "diamond", "triangle") #defining shapes for ggplot points


#PLOTTING 

#1. Fortifying the ordination that will be plotted with ggvegan package
#The convention with ggplot2 is to `fortify()` the object we wish to plot, 
#which basically means turn the object into a format that is suitable for plotting with `ggplot()`
ford2 <- fortify(struga.cca2, axes = 1:2, scaling = "symmetric")
sites2 <- fortify(struga.cca2, axes = 1:2, scaling = "symmetric", display = "wa")
species2 <- fortify(struga.cca2, axes = 1:2, scaling = "symmetric", display = "species")
bp2 <- fortify (struga.cca2, axes = 1:2, scaling = "symmetric", display = "bp")
#create a tibble 
head(ford2, 10)
tail(ford2,10)
#add factor for water layer column
sites2 <- sites2 %>%
  bind_cols(strugaf)
colnames(sites2)[8] <- "Waterlayer"
colnames(sites2)[9] <- "ITW"

#2. plot struga.cca2 model 
p2 <- ggplot(ford2, aes(x = CCA1, y = CCA2)) +
  geom_hline(yintercept = 0, colour = "gray", alpha = 0.5) +
  geom_vline(xintercept = 0, colour = "gray", alpha = 0.5) +   
  geom_point(data = sites2, 
             mapping = aes(colour = Waterlayer), size=4) +
  scale_color_manual(values = cols) +
  geom_label(data = species2, label=species2$label, label.size = 0.5, cex=7)+
  geom_label(data = bp2, label=bp2$label, label.size = 0.5, cex=7)+
  geom_segment(mapping = aes(x=0, y=0, xend=CCA1*10, yend=CCA2*10),
               arrow=arrow(length = unit(0.8, "cm")), 
               data=filter(bp2),color="black") +
  theme_classic()+
  theme(axis.text.y = element_text(size = rel(3), angle = 00),
        axis.text.x = element_text(size = rel(3), angle = 00),
        axis.title.y = element_text(size = rel(1.7), angle = 90),
        axis.title.x = element_text(size = rel(1.7), angle = 00),
        legend.title = element_blank(),
        legend.key.size = unit(1.3, "cm"),
        legend.text = element_text(size = unit(15, "cm")),
        legend.position = "right",
        axis.text = element_text(size = 6))+
  labs(x = "CCA1 (44.48%, p = 0.001)", y = "CCA2 (0.29%, p = 0.997)") + 
  annotate("text", x = Inf, y = Inf, 
           label = "Total of 44.82% (p=0.001) variability is explained by constrained axes", 
           hjust = 1, vjust = 1, cex=7)  

ggsave("CCA_pico.pdf", plot = p2, width = 12, height = 10, units = "in", device = "pdf")
