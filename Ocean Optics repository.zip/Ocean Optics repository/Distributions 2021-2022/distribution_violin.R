source("C:/Users/Antonija/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza/Data_coherence_I_II_III/Correlation/packages.R")

#Load end edit data
env21 <- readxl::read_xlsx("C:/Users/Tihomir/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza/Data_coherence_I_II_III/Correlation/environment_21.xlsx")
env22 <- readxl::read_xlsx("C:/Users/Tihomir/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza/Data_coherence_I_II_III/Correlation/environment_22.xlsx")
env21$PO4 <- as.numeric(env21$PO4)
env23 <-  readxl::read_xlsx("C:/Users/Tihomir/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza/Data_coherence_I_II_III/Correlation/environment_23.xlsx")
env23$Date <- as.POSIXct(
  gsub("\\.$", "", env23$Date),  # remove trailing dot
  format = "%d.%m.%y",
  tz = "UTC"
)

#Add column for the year and combine
env21 <- env21 %>% mutate(Year = "2021")
env22 <- env22 %>% mutate(Year = "2022")
env23 <- env23 %>% mutate(Year = "2023")
env <- bind_rows(env21, env22, env23)

#Set category as a factor, reorder and transform to capslock
env$Category <- factor(
  toupper(env$Category),
  levels = c("SURFACE", "THERMOCLINE", "DEEP LAYER")
)

#Define variables and layers for visualization
vars <- c(
  "NO3", "NO2", "PO4", "SiO4",
  "Chla",
  "Temperature (°C)",
  "Salinity",
  "Density"
)
layers <- c("SURFACE", "THERMOCLINE", "DEEP LAYER")


#**Violin distributions* 

p1 <- ggplot(env, aes(x = Year, y = NO3, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")

p2 <- ggplot(env, aes(x = Year, y = NO2, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")

p3 <- ggplot(env, aes(x = Year, y = PO4, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")

p4 <- ggplot(env, aes(x = Year, y = SiO4, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")

p5 <- ggplot(env, aes(x = Year, y = Chla, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")


p6 <- ggplot(env, aes(x = Year, y = `Temperature (°C)`, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")

p7 <- ggplot(env, aes(x = Year, y = Density, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")

p8 <- ggplot(env, aes(x = Year, y = Salinity, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")

#Final plot
P <- plot_grid(
  p1, p2, p3, p4,
  ncol = 1,
  align = "hv")
P1 <- plot_grid(
  p5, p6, p7, p8,
  ncol = 1,
  align = "hv")
P
P1

#Save final plots
ggsave(
  filename = "distributions1.jpg",
  plot = P,
  width = 14,
  height = 7,
  dpi = 300,
  units = "in"
)
ggsave(
  filename = "distributions2.jpg",
  plot = P1,
  width = 14,
  height = 7,
  dpi = 300,
  units = "in"
)


#**Calculate z-score and remove the outliers if present*
env_z <- env %>%
  mutate(across(
    all_of(vars),
    ~ ( .x - mean(.x, na.rm = TRUE) ) / sd(.x, na.rm = TRUE),
    .names = "{.col}_z"
  ))

replace_extreme_z <- function(df, z_thresh = 1.96) {
  
  df %>%
    mutate(across(
      where(is.numeric),
      ~ {
        z <- ( .x - mean(.x, na.rm = TRUE) ) / sd(.x, na.rm = TRUE)
        ifelse(abs(z) > z_thresh, NA, .x)
      }
    ))
}

env_z1<- replace_extreme_z(env_z, z_thresh = 1.96)

#Count home many variables was removed
removed_counts <-  function(env_z, env_z1, vars, year_col = "Year") {
  
  vars_ok <- intersect(vars, intersect(names(env_z), names(env_z1)))
  
  # keep only Year + vars (and ensure same rows/order in both dfs)
  df_before <- env_z  %>% select(all_of(year_col), all_of(vars_ok))
  df_after  <- env_z1 %>% select(all_of(year_col), all_of(vars_ok))
  
  # long format for counting
  before_long <- df_before %>%
    pivot_longer(cols = all_of(vars_ok), names_to = "variable", values_to = "value_before")
  
  after_long <- df_after %>%
    pivot_longer(cols = all_of(vars_ok), names_to = "variable", values_to = "value_after")
  
  # join row-by-row (safe join key = row number)
  res <- bind_cols(
    before_long %>% select(all_of(year_col), variable, value_before),
    after_long  %>% select(value_after)
  ) %>%
    group_by(.data[[year_col]], variable) %>%
    summarise(
      n_before = sum(is.na(value_before)),
      n_after  = sum(is.na(value_after)),
      introduced = n_after - n_before,
      n_total = n(),
      introduced_pct = 100 * introduced / n_total,
      .groups = "drop"
    ) %>%
    arrange(.data[[year_col]], desc(introduced))
  
  res
}

df <- removed_counts(env_z, env_z1, vars)
df
write_xlsx(df, "env_count_of_removed_values.xlsx")


#**Violin distributions with extremes removed**
p1_z <- ggplot(env_z1, aes(x = Year, y = NO3, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")

p2_z <- ggplot(env_z1, aes(x = Year, y = NO2, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")

p3_z <- ggplot(env_z1, aes(x = Year, y = PO4, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")

p4_z <- ggplot(env_z1, aes(x = Year, y = SiO4, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")

p5_z <- ggplot(env_z1, aes(x = Year, y = Chla, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")


p6_z <- ggplot(env_z1, aes(x = Year, y = `Temperature (°C)`, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")

p7_z <- ggplot(env_z1, aes(x = Year, y = Density, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")

p8_z <- ggplot(env_z1, aes(x = Year, y = Salinity, fill = Year)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, outlier.shape = NA) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw()+ 
  theme(legend.position = "none")


#Final plot
P_z <- plot_grid(
  p1_z, p2_z, p3_z, p4_z,
  ncol = 1,
  align = "hv")
P1_z <- plot_grid(
  p5_z, p6_z, p7_z, p8_z,
  ncol = 1,
  align = "hv")
P_z
P1_z

#Save final plots
ggsave(
  filename = "distributions1_z.jpg",
  plot = P_z,
  width = 14,
  height = 7,
  dpi = 300,
  units = "in"
)

ggsave(
  filename = "distributions2_z.jpg",
  plot = P1_z,
  width = 14,
  height = 7,
  dpi = 300,
  units = "in"
)


#**Violin distributions with extremes removed repeated for 2023 points overlaid**
env_z1_23rep <- env_z1 %>%
  filter(Year == "2023") %>%
  tidyr::crossing(RefYear = c("2021", "2022")) %>%
  mutate(Year = RefYear) %>%   # overwrite Year for plotting
  select(-RefYear)


p1_z1 <- ggplot() +
  geom_violin(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y =  NO3, fill = Year),
    trim = FALSE,
    alpha = 0.5
  ) +
  geom_boxplot(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y =  NO3, fill = Year),
    width = 0.1,
    outlier.shape = NA
  ) +
  geom_jitter(
    data = env_z1_23rep,
    aes(x = Year, y =  NO3),
    width = 0.08,
    height = 0,
    size = 2,
    colour = "black"
  ) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw() +
  theme(legend.position = "none")

p2_z1 <-  ggplot() +
  geom_violin(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y =  NO2, fill = Year),
    trim = FALSE,
    alpha = 0.5
  ) +
  geom_boxplot(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y =  NO2, fill = Year),
    width = 0.1,
    outlier.shape = NA
  ) +
  geom_jitter(
    data = env_z1_23rep,
    aes(x = Year, y =  NO2),
    width = 0.08,
    height = 0,
    size = 2,
    colour = "black"
  ) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw() +
  theme(legend.position = "none")


p3_z1 <- ggplot() +
  geom_violin(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y =  PO4, fill = Year),
    trim = FALSE,
    alpha = 0.5
  ) +
  geom_boxplot(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y =  PO4, fill = Year),
    width = 0.1,
    outlier.shape = NA
  ) +
  geom_jitter(
    data = env_z1_23rep,
    aes(x = Year, y =  PO4),
    width = 0.08,
    height = 0,
    size = 2,
    colour = "black"
  ) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw() +
  theme(legend.position = "none")

p4_z1 <- ggplot() +
  geom_violin(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = SiO4, fill = Year),
    trim = FALSE,
    alpha = 0.5
  ) +
  geom_boxplot(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = SiO4, fill = Year),
    width = 0.1,
    outlier.shape = NA
  ) +
  geom_jitter(
    data = env_z1_23rep,
    aes(x = Year, y = SiO4),
    width = 0.08,
    height = 0,
    size = 2,
    colour = "black"
  ) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw() +
  theme(legend.position = "none")

p5_z1 <- ggplot() +
geom_violin(
  data = env_z1 %>% filter(Year %in% c("2021", "2022")),
  aes(x = Year, y = Chla, fill = Year),
  trim = FALSE,
  alpha = 0.5
) +
geom_boxplot(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = Chla, fill = Year),
    width = 0.1,
    outlier.shape = NA
  ) +
  geom_jitter(
    data = env_z1_23rep,
    aes(x = Year, y = Chla),
    width = 0.08,
    height = 0,
    size = 2,
    colour = "black"
  ) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw() +
  theme(legend.position = "none")

p6_z1 <- ggplot() +
  geom_violin(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y =  `Temperature (°C)`, fill = Year),
    trim = FALSE,
    alpha = 0.5
  ) +
  geom_boxplot(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y =  `Temperature (°C)`, fill = Year),
    width = 0.1,
    outlier.shape = NA
  ) +
  geom_jitter(
    data = env_z1_23rep,
    aes(x = Year, y =  `Temperature (°C)`),
    width = 0.08,
    height = 0,
    size = 2,
    colour = "black"
  ) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw() +
  theme(legend.position = "none")

p7_z1 <- ggplot() +
  geom_violin(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = Density, fill = Year),
    trim = FALSE,
    alpha = 0.5
  ) +
  geom_boxplot(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = Density, fill = Year),
    width = 0.1,
    outlier.shape = NA
  ) +
  geom_jitter(
    data = env_z1_23rep,
    aes(x = Year, y = Density),
    width = 0.08,
    height = 0,
    size = 2,
    colour = "black"
  ) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw() +
  theme(legend.position = "none")

p8_z1 <- ggplot() +
  geom_violin(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = Salinity, fill = Year),
    trim = FALSE,
    alpha = 0.5
  ) +
  geom_boxplot(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = Salinity, fill = Year),
    width = 0.1,
    outlier.shape = NA
  ) +
  geom_jitter(
    data = env_z1_23rep,
    aes(x = Year, y = Salinity),
    width = 0.08,
    height = 0,
    size = 2,
    colour = "black"
  ) +
  facet_wrap(~ Category, scales = "free_y") +
  theme_bw() +
  theme(legend.position = "none")


#Final plot
P_z1 <- plot_grid(
  p1_z1, p2_z1, p3_z1, p4_z1,
  ncol = 1,
  align = "hv")
P1_z1<- plot_grid(
  p5_z1, p6_z1, p7_z1, p8_z1,
  ncol = 1,
  align = "hv")



P_z1
P1_z1


#Save final plots
ggsave(
  filename = "distributions1_z_plus23.jpg",
  plot = P_z1,
  width = 14,
  height = 7,
  dpi = 300,
  units = "in"
)

ggsave(
  filename = "distributions2_z_plus23.jpg",
  plot = P1_z1,
  width = 14,
  height = 7,
  dpi = 300,
  units = "in"
)



#**Compare 2023 values against the 5th–95th percentile range derived from pooled July 2021–2022 data*
percent_within_envelope <- function(df, var_name, layer_name,
                                    lower_q = 0.05, upper_q = 0.95) {
  
  baseline <- df %>%
    filter(Year %in% c("2021", "2022"),
           Category == layer_name) %>%
    pull(all_of(var_name)) %>%
    .[is.finite(.)]
  
  vals_2023 <- df %>%
    filter(Year == "2023",
           Category == layer_name) %>%
    pull(all_of(var_name)) %>%
    .[is.finite(.)]
  
  if (length(vals_2023) == 0 || length(baseline) < 5) {
    return(tibble(
      variable = var_name,
      layer = layer_name,
      n_2023 = length(vals_2023),
      pct_within = NA_real_,
      q05 = NA_real_,
      q95 = NA_real_
    ))
  }
  
  q_low  <- as.numeric(quantile(baseline, probs = lower_q, na.rm = TRUE))
  q_high <- as.numeric(quantile(baseline, probs = upper_q, na.rm = TRUE))
  
  pct_within <- mean(vals_2023 >= q_low & vals_2023 <= q_high) * 100
  
  tibble(
    variable = var_name,
    layer = layer_name,
    n_2023 = length(vals_2023),
    pct_within = pct_within,
    q05 = q_low,
    q95 = q_high
  )
}


percentile23 <- tidyr::crossing(variable = vars, layer = layers) %>%
  rowwise() %>%
  do(percent_within_envelope(env_z1, .$variable, .$layer)) %>%
  ungroup()

percentile23
write_xlsx(percentile23, "percentile23.xlsx")



#**Shown only in thermocline*

vars_env <- c("Chla", "NO3", "PO4", "SiO4", "Temperature (°C)", "Salinity", "Density")

facet_labels <- c(
  "Chla" = "Chl a",
  "NO3" = "NO3",
  "PO4" = "PO4",
  "SiO4" = "SiO4",
  "Temperature (°C)" = "Temperature",
  "Salinity" = "Salinity",
  "Density" = "Density"
)


# --- Thermocline only + long format ---
env_th <- env_z1 %>%
  filter(Category == "THERMOCLINE")

env_th_23rep <- env_th %>%
  filter(Year == "2023") %>%
  tidyr::crossing(RefYear = c("2021", "2022")) %>%
  mutate(Year = RefYear) %>%
  select(-RefYear)

env_th_long_2122 <- env_th %>%
  filter(Year %in% c("2021", "2022")) %>%
  pivot_longer(
    cols = all_of(vars_env),
    names_to = "Variable",
    values_to = "Value"
  ) %>%
  mutate(
    Year = factor(Year, levels = c("2021","2022")),
    Variable = factor(Variable, levels = vars_env)
  )

env_th_long_23rep <- env_th_23rep %>%
  pivot_longer(
    cols = all_of(vars_env),
    names_to = "Variable",
    values_to = "Value"
  ) %>%
  mutate(
    Year = factor(Year, levels = c("2021","2022")),
    Variable = factor(Variable, levels = vars_env)
  )

p_env_thermo <- ggplot() +
  geom_violin(
    data = env_th_long_2122,
    aes(x = Year, y = Value, fill = Year),
    trim = FALSE,
    alpha = 0.5
  ) +
  geom_boxplot(
    data = env_th_long_2122,
    aes(x = Year, y = Value, fill = Year),
    width = 0.1,
    outlier.shape = NA
  ) +
  geom_jitter(
    data = env_th_long_23rep,
    aes(x = Year, y = Value),
    width = 0.08,
    height = 0,
    size = 2,
    colour = "black"
  ) +
  facet_wrap(~ Variable, scales = "free_y", ncol = 4,
             labeller = labeller(Variable = facet_labels)) +
  theme_bw() +
  theme(
    legend.position = "none",
    strip.text = element_text(face = "bold")
  ) +
  labs(x = NULL, y = NULL, title = NULL)

p_env_thermo


ggsave(
  filename = "env_distributions_thermocline.jpg",
  plot = p_env_thermo,
  width = 14,
  height = 7,
  dpi = 300,
  units = "in"
)



#**plot for paper*

library(ggplot2)
library(dplyr)
library(cowplot)

big_theme <- theme_bw(base_size = 25) +
  theme(
    legend.position = "none",
    
    axis.text.x  = element_text(size = 36, face = "bold"),
    axis.text.y  = element_text(size = 36, face = "bold"),
    
    axis.title.x = element_text(size = 40, face = "bold"),
    axis.title.y = element_text(size = 40, face = "bold"),
    
    strip.text   = element_text(size = 34, face = "bold"),
    
    panel.border = element_rect(linewidth = 1),
    axis.line    = element_line(linewidth = 0.8)
  )

big_theme_no_strips <- big_theme +
  theme(
    strip.text = element_blank(),
    strip.background = element_blank()
  )

p1_z1 <- ggplot() +
  geom_violin(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = NO3),
    trim = FALSE, linewidth = 1.5
  ) +
  geom_boxplot(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = NO3),
    width = 0.1, outlier.shape = NA, linewidth = 0.8
  ) +
  geom_jitter(
    data = env_z1_23rep,
    aes(x = Year, y = NO3),
    width = 0, height = 0, size = 4, colour = "black"
  ) +
  facet_wrap(~ Category, scales = "free_y") +
  labs(x = NULL, y = NULL) +
  big_theme_no_strips

p3_z1 <- ggplot() +
  geom_violin(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = PO4),
    trim = FALSE, linewidth = 1.5
  ) +
  geom_boxplot(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = PO4),
    width = 0.1, outlier.shape = NA, linewidth = 0.8
  ) +
  geom_jitter(
    data = env_z1_23rep,
    aes(x = Year, y = PO4),
    width = 0, height = 0, size = 4, colour = "black"
  ) +
  facet_wrap(~ Category, scales = "free_y") +
  labs(x = NULL, y = NULL) +
  big_theme_no_strips

p4_z1 <- ggplot() +
  geom_violin(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = SiO4),
    trim = FALSE, linewidth = 1.5
  ) +
  geom_boxplot(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = SiO4),
    width = 0.1, outlier.shape = NA, linewidth = 0.8
  ) +
  geom_jitter(
    data = env_z1_23rep,
    aes(x = Year, y = SiO4),
    width = 0, height = 0, size = 4, colour = "black"
  ) +
  facet_wrap(~ Category, scales = "free_y") +
  labs(x = NULL, y = NULL) +
  big_theme_no_strips

p5_z1 <- ggplot() +
  geom_violin(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = Chla),
    trim = FALSE,  linewidth = 1.5
  ) +
  geom_boxplot(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = Chla),
    width = 0.1, outlier.shape = NA, linewidth = 0.8
  ) +
  geom_jitter(
    data = env_z1_23rep,
    aes(x = Year, y = Chla),
    width = 0, height = 0, size = 4, colour = "black"
  ) +
  facet_wrap(~ Category, scales = "free_y") +
  labs(x = NULL, y = NULL) +
  big_theme_no_strips

p6_z1 <- ggplot() +
  geom_violin(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = `Temperature (°C)`),
    trim = FALSE, linewidth = 1.5
  ) +
  geom_boxplot(
    data = env_z1 %>% filter(Year %in% c("2021", "2022")),
    aes(x = Year, y = `Temperature (°C)`),
    width = 0.1, outlier.shape = NA, linewidth = 0.8
  ) +
  geom_jitter(
    data = env_z1_23rep,
    aes(x = Year, y = `Temperature (°C)`),
    width = 0, height = 0, size = 4, colour = "black"
  ) +
  facet_wrap(~ Category, scales = "free_y") +
  labs(x = NULL, y = NULL) +
  big_theme


p1_z1 <- p1_z1 + labs(y = "NO3 [µmol L-1]")
p3_z1 <- p3_z1 + labs(y = "PO4 [µmol L-1]")
p4_z1 <- p4_z1 + labs(y = "SiO4 [µmol L-1]")
p5_z1 <- p5_z1 + labs(y = "Chl a [mg m-3]")
p6_z1 <- p6_z1 + labs(y = "Temperature [°C]")

p1_z1 <- p1_z1 + labs(
  y = expression(bold(NO[3]~"["*mu*"mol L"^{-1}*"]"))
)

p3_z1 <- p3_z1 + labs(
  y = expression(bold(PO[4]~"["*mu*"mol L"^{-1}*"]"))
)

p4_z1 <- p4_z1 + labs(
  y = expression(bold(SiO[4]~"["*mu*"mol L"^{-1}*"]"))
)

p5_z1 <- p5_z1 + labs(
  y = expression(bold(Chl~italic(a)~"[mg m"^{-3}*"]"))
)

p6_z1 <- p6_z1 + labs(
  y = expression(bold(Temperature~"["*degree*C*"]"))
)
P2_z1  <- plot_grid(p6_z1,p5_z1,
                    p1_z1, p3_z1, p4_z1,
                    ncol = 1,
                    align = "hv")
P2_z1

ggsave(
  filename = "distributions_2021-2023_20260821.pdf",
  plot = P2_z1,
  width = 28,
  height = 20,
  dpi = 300,
  units = "in"
)

ggsave(
  filename = "distributions_2021-2023_20260821.tif",
  plot = P2_z1,
  width = 28,
  height = 28,
  dpi = 300,
  units = "in"
)


